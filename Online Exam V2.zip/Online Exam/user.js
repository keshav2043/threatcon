// User Module - User Dashboard and Features

function loadCoursesPage() {
    const courses = db.getAllCourses();
    const container = document.getElementById('courses-grid');
    
    if (courses.length === 0) {
        container.innerHTML = '<p>No courses available at the moment.</p>';
        return;
    }

    container.innerHTML = courses.map(course => {
        const subject = db.getSubjectById(course.subjectId);
        const isEnrolled = auth.getCurrentUser().enrolledCourses && 
                          auth.getCurrentUser().enrolledCourses.includes(course.id);
        
        return `
            <div class="course-card">
                <div class="course-header">
                    <h3>${course.name}</h3>
                    <span class="subject-badge">${subject ? subject.name : 'N/A'}</span>
                </div>
                <p class="course-description">${course.description}</p>
                <div class="course-meta">
                    <span>📚 Reading Material: ${course.readingMaterial ? 'Available' : 'N/A'}</span>
                    <span>💰 Fee: Rs. ${course.fee}</span>
                </div>
                <div class="course-actions">
                    <button onclick="enrollCourse('${course.id}')" 
                            class="btn btn-primary" ${isEnrolled ? 'disabled' : ''}>
                        ${isEnrolled ? 'Already Enrolled' : 'Enroll Now'}
                    </button>
                    ${course.readingMaterial ? 
                        `<button onclick="viewReadingMaterial('${course.readingMaterial}')" class="btn btn-secondary">
                            View Materials
                        </button>` : ''}
                </div>
            </div>
        `;
    }).join('');

    // Populate subject filter
    const subjects = db.getAllSubjects();
    const subjectFilter = document.getElementById('subjectFilter');
    subjectFilter.innerHTML = '<option value="">All Subjects</option>' +
        subjects.map(s => `<option value="${s.id}">${s.name}</option>`).join('');
}

function filterCourses() {
    const searchQuery = document.getElementById('courseFilter').value.toLowerCase();
    const subjectFilter = document.getElementById('subjectFilter').value;
    
    let courses = db.getAllCourses();
    
    if (searchQuery) {
        courses = courses.filter(c => 
            c.name.toLowerCase().includes(searchQuery) ||
            c.description.toLowerCase().includes(searchQuery)
        );
    }
    
    if (subjectFilter) {
        courses = courses.filter(c => c.subjectId === subjectFilter);
    }

    const container = document.getElementById('courses-grid');
    if (courses.length === 0) {
        container.innerHTML = '<p>No courses found matching your criteria.</p>';
        return;
    }

    container.innerHTML = courses.map(course => {
        const subject = db.getSubjectById(course.subjectId);
        const isEnrolled = auth.getCurrentUser().enrolledCourses && 
                          auth.getCurrentUser().enrolledCourses.includes(course.id);
        
        return `
            <div class="course-card">
                <div class="course-header">
                    <h3>${course.name}</h3>
                    <span class="subject-badge">${subject ? subject.name : 'N/A'}</span>
                </div>
                <p class="course-description">${course.description}</p>
                <div class="course-meta">
                    <span>📚 Reading Material: ${course.readingMaterial ? 'Available' : 'N/A'}</span>
                    <span>💰 Fee: Rs. ${course.fee}</span>
                </div>
                <div class="course-actions">
                    <button onclick="enrollCourse('${course.id}')" 
                            class="btn btn-primary" ${isEnrolled ? 'disabled' : ''}>
                        ${isEnrolled ? 'Already Enrolled' : 'Enroll Now'}
                    </button>
                    ${course.readingMaterial ? 
                        `<button onclick="viewReadingMaterial('${course.readingMaterial}')" class="btn btn-secondary">
                            View Materials
                        </button>` : ''}
                </div>
            </div>
        `;
    }).join('');
}

function enrollCourse(courseId) {
    const user = auth.getCurrentUser();
    if (!user.enrolledCourses) {
        user.enrolledCourses = [];
    }
    
    if (!user.enrolledCourses.includes(courseId)) {
        user.enrolledCourses.push(courseId);
        auth.updateProfile(user.id, user);
        alert('Successfully enrolled in course!');
        loadCoursesPage();
    }
}

function viewReadingMaterial(materialUrl) {
    if (!materialUrl) {
        alert('No reading material available');
        return;
    }
    window.open(materialUrl, '_blank');
}

// ========== EXAM MANAGEMENT ==========

function loadExamsPage() {
    const assignments = db.getAllAssignments();
    const container = document.getElementById('exams-list');
    const user = auth.getCurrentUser();

    // Get both regular and user-assigned exams
    const userAssignments = db.getUserAssignments(user.id);
    const assignedAssignmentIds = userAssignments.map(ua => ua.assignmentId);
    
    // Show assigned exams first, then all available exams
    const allExams = assignments.map(a => ({
        ...a,
        assigned: assignedAssignmentIds.includes(a.id)
    }));

    if (allExams.length === 0) {
        container.innerHTML = '<p>No exams available at the moment.</p>';
        return;
    }

    container.innerHTML = allExams.map(assignment => {
        const course = db.getCourseById(assignment.courseId);
        const subject = db.getSubjectById(assignment.subjectId);
        
        // Check if user has subscribed to this course
        const isEnrolled = user.enrolledCourses && user.enrolledCourses.includes(assignment.courseId);
        const subscription = db.getUserSubscription(user.id);
        const canTake = isEnrolled || (subscription && subscription.active) || assignment.assigned;

        // Check if already attempted
        const previousAttempt = db.getExamResponsesByAssignment(assignment.id)
            .find(r => r.userId === user.id);

        return `
            <div class="exam-card ${assignment.assigned ? 'assigned-exam' : ''}">
                <div class="exam-header">
                    <h3>${assignment.name}</h3>
                    <span class="exam-badge">${course ? course.name : subject ? subject.name : 'N/A'}</span>
                    ${assignment.assigned ? '<span class="badge" style="background-color: #10b981; color: white;">🎯 Assigned</span>' : ''}
                </div>
                <div class="exam-details">
                    <p><strong>Subject:</strong> ${subject ? subject.name : 'N/A'}</p>
                    <p><strong>Total Questions:</strong> ${assignment.questionIds.length}</p>
                    <p><strong>Total Marks:</strong> ${assignment.totalMarks}</p>
                    <p><strong>Duration:</strong> ${assignment.duration} minutes</p>
                    <p><strong>Marks per Question:</strong> ${assignment.marksPerQuestion.toFixed(2)}</p>
                    ${assignment.isMixed ? '<p><span class="badge" style="background-color: #f59e0b;">📊 Mixed Questions</span></p>' : ''}
                </div>
                <div class="exam-actions">
                    ${!canTake ? 
                        `<p class="warning">⚠️ Please enroll in the course or subscribe to take this exam</p>` : 
                        `<button onclick="startExam('${assignment.id}')" class="btn btn-primary">
                            ${previousAttempt ? 'Retake Exam' : 'Start Exam'}
                        </button>`
                    }
                </div>
                ${previousAttempt ? 
                    `<div class="previous-attempt">
                        <span>Last Attempt: ${previousAttempt.percentage}% (${previousAttempt.status})</span>
                    </div>` : ''
                }
            </div>
        `;
    }).join('');
}

// ========== SUBSCRIPTION MANAGEMENT ==========

function loadSubscriptionPlans() {
    const container = document.getElementById('subscription-plans');
    const user = auth.getCurrentUser();
    const currentSubscription = db.getUserSubscription(user.id);

    const plans = [
        {
            id: 'basic',
            name: 'Basic Plan',
            price: 500,
            duration: 30,
            features: [
                'Access to 10 courses',
                'Take practice tests',
                'View results and analytics',
                '30 days access'
            ]
        },
        {
            id: 'pro',
            name: 'Pro Plan',
            price: 1500,
            duration: 90,
            features: [
                'Access to all courses',
                'Unlimited practice tests',
                'View detailed analytics',
                'Download study materials',
                '90 days access',
                'Email support'
            ]
        },
        {
            id: 'premium',
            name: 'Premium Plan',
            price: 3500,
            duration: 365,
            features: [
                'Lifetime access to all courses',
                'Unlimited practice tests',
                'Advanced analytics',
                'Download all materials',
                '1 year access',
                'Priority email support',
                'Certificate of completion'
            ]
        }
    ];

    container.innerHTML = plans.map(plan => {
        const isCurrentPlan = currentSubscription && currentSubscription.plan === plan.id;
        
        return `
            <div class="plan-card ${isCurrentPlan ? 'active' : ''}">
                <div class="plan-header">
                    <h3>${plan.name}</h3>
                    <div class="plan-price">
                        <span class="amount">Rs. ${plan.price}</span>
                        <span class="duration">/ ${plan.duration} days</span>
                    </div>
                </div>
                <ul class="plan-features">
                    ${plan.features.map(f => `<li>✓ ${f}</li>`).join('')}
                </ul>
                <button 
                    onclick="subscribePlan('${plan.id}', '${plan.name}', ${plan.price})"
                    class="btn ${isCurrentPlan ? 'btn-secondary' : 'btn-primary'}"
                    ${isCurrentPlan ? 'disabled' : ''}>
                    ${isCurrentPlan ? 'Current Plan' : 'Subscribe Now'}
                </button>
            </div>
        `;
    }).join('');
}

function subscribePlan(planId, planName, price) {
    if (!confirm(`Subscribe to ${planName} for Rs. ${price}?`)) {
        return;
    }

    const user = auth.getCurrentUser();
    
    // Record payment
    const payment = db.recordPayment({
        userId: user.id,
        planId,
        amount: price,
        status: 'completed'
    });

    // Create subscription
    const expiryDate = new Date();
    const durationDays = planId === 'basic' ? 30 : planId === 'pro' ? 90 : 365;
    expiryDate.setDate(expiryDate.getDate() + durationDays);

    const subscription = db.addSubscription({
        userId: user.id,
        plan: planId,
        startDate: new Date().toISOString(),
        expiryDate: expiryDate.toISOString(),
        active: true,
        paymentId: payment.id
    });

    // Update user
    user.subscriptionStatus = planId;
    auth.updateProfile(user.id, user);

    alert(`Successfully subscribed to ${planName}! Your subscription is valid until ${expiryDate.toLocaleDateString()}`);
    loadSubscriptionPlans();
}

// ========== USER PROFILE ==========

function loadUserProfile() {
    const user = auth.getCurrentUser();
    const subscription = db.getUserSubscription(user.id);
    const examResponses = db.getUserExamResponses(user.id);

    const userInfoHTML = `
        <div class="profile-header">
            <h3>${user.name}</h3>
            <p>Email: ${user.email}</p>
            <p>Member Since: ${new Date(user.createdAt).toLocaleDateString()}</p>
        </div>
        <div class="profile-details">
            <div class="detail-row">
                <span>Subscription Status:</span>
                <span class="badge">${subscription ? subscription.plan.toUpperCase() : 'None'}</span>
            </div>
            <div class="detail-row">
                <span>Enrolled Courses:</span>
                <span>${user.enrolledCourses ? user.enrolledCourses.length : 0}</span>
            </div>
            <div class="detail-row">
                <span>Exams Taken:</span>
                <span>${examResponses.length}</span>
            </div>
            ${subscription ? `
                <div class="detail-row">
                    <span>Subscription Valid Until:</span>
                    <span>${new Date(subscription.expiryDate).toLocaleDateString()}</span>
                </div>
            ` : ''}
        </div>
    `;

    document.getElementById('user-info').innerHTML = userInfoHTML;

    // Load exam history
    const historyHTML = examResponses.map(exam => {
        const assignment = db.getAssignmentById(exam.assignmentId);
        return `
            <div class="history-item">
                <h4>${assignment ? assignment.name : 'N/A'}</h4>
                <div class="history-details">
                    <span>Score: ${exam.score}/${exam.totalMarks}</span>
                    <span>Percentage: ${exam.percentage}%</span>
                    <span class="status-badge ${exam.status.toLowerCase()}">${exam.status}</span>
                    <span>Date: ${new Date(exam.submittedAt).toLocaleDateString()}</span>
                </div>
                ${exam.status === 'PASS' ? `
                    <button onclick="downloadCertificateForHistory('${exam.assignmentId}', '${exam.submittedAt}')" class="btn btn-secondary btn-sm">
                        Download Certificate
                    </button>
                ` : ''}
            </div>
        `;
    }).join('');

    document.getElementById('user-exams').innerHTML = historyHTML || 
        '<p>You haven\'t taken any exams yet.</p>';
}

function downloadCertificate(examName, score, totalMarks, percentage, status, submittedDate) {
    const user = auth.getCurrentUser();
    const canvas = document.createElement('canvas');
    const width = 1600;
    const height = 1100;
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');

    // Background
    const gradient = ctx.createLinearGradient(0, 0, width, height);
    gradient.addColorStop(0, '#0f172a');
    gradient.addColorStop(1, '#2563eb');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);

    // Certificate panel
    ctx.fillStyle = 'rgba(255, 255, 255, 0.95)';
    ctx.fillRect(80, 120, width - 160, height - 240);

    // Border
    ctx.strokeStyle = '#2563eb';
    ctx.lineWidth = 10;
    ctx.strokeRect(100, 140, width - 200, height - 280);

    // Text styling
    ctx.fillStyle = '#111827';
    ctx.font = 'bold 70px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('Certificate of Achievement', width / 2, 260);

    ctx.fillStyle = '#374151';
    ctx.font = '24px Arial';
    ctx.fillText('This certifies that', width / 2, 340);

    ctx.fillStyle = '#111827';
    ctx.font = 'bold 60px Arial';
    ctx.fillText(user.name, width / 2, 430);

    ctx.fillStyle = '#4b5563';
    ctx.font = '24px Arial';
    ctx.fillText(`has successfully completed the exam`, width / 2, 500);

    ctx.fillStyle = '#111827';
    ctx.font = 'bold 50px Arial';
    ctx.fillText(examName, width / 2, 580);

    ctx.fillStyle = '#4b5563';
    ctx.font = '26px Arial';
    ctx.fillText(`Score: ${score}/${totalMarks} • Percentage: ${percentage}% • Status: ${status}`, width / 2, 660);
    ctx.fillText(`Date: ${submittedDate}`, width / 2, 720);

    // Signature line
    ctx.strokeStyle = '#111827';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(width / 2 - 260, 820);
    ctx.lineTo(width / 2 + 260, 820);
    ctx.stroke();
    ctx.font = '22px Arial';
    ctx.fillStyle = '#111827';
    ctx.fillText('Authorized Signature', width / 2, 860);

    const link = document.createElement('a');
    link.href = canvas.toDataURL('image/png');
    const safeExamName = examName.replace(/[^a-z0-9]/gi, '_').toLowerCase();
    const safeUserName = user.name.replace(/[^a-z0-9]/gi, '_').toLowerCase();
    link.download = `certificate_${safeUserName}_${safeExamName}.png`;
    link.click();
}

function downloadCertificateFromCurrentResult() {
    if (!currentExamResponse || !currentExam) {
        alert('Certificate details are not available.');
        return;
    }
    downloadCertificate(currentExam.name, currentExamResponse.score, currentExamResponse.totalMarks, currentExamResponse.percentage, currentExamResponse.status, new Date(currentExamResponse.submittedAt).toLocaleDateString());
}

function downloadCertificateForHistory(assignmentId, submittedAt) {
    const user = auth.getCurrentUser();
    const exam = db.getUserExamResponses(user.id)
        .find(r => r.assignmentId === assignmentId && r.submittedAt === submittedAt);
    if (!exam) {
        alert('Certificate information not found.');
        return;
    }
    const assignment = db.getAssignmentById(assignmentId);
    if (!assignment) {
        alert('Assignment information not found.');
        return;
    }
    downloadCertificate(assignment.name, exam.score, exam.totalMarks, exam.percentage, exam.status, new Date(exam.submittedAt).toLocaleDateString());
}

// ========== STATISTICS ==========

function updatePageStatistics() {
    const stats = db.getStatistics();
    document.getElementById('totalCourses').textContent = stats.totalCourses;
    document.getElementById('totalQuestions').textContent = stats.totalQuestions;
    document.getElementById('totalExams').textContent = stats.totalAssignments;
    document.getElementById('totalUsers').textContent = stats.totalUsers;
}
