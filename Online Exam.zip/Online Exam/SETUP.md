# 🚀 ExamHub - Quick Setup Guide

## Step-by-Step Setup Instructions

### **Step 1: File Structure**
Make sure all files are in the same directory:
```
Online Exam/
├── index.html
├── styles.css
├── db.js
├── auth.js
├── admin.js
├── exam.js
├── user.js
├── app.js
├── sample-data.js
└── README.md
```

### **Step 2: Open the Application**
1. Open `index.html` in your web browser
2. The system will initialize automatically
3. Login modal will appear

### **Step 3: Login with Demo Account**

**Option A: As Admin**
- Email: `admin@examhub.com`
- Password: `admin123`
- Access: Full admin panel with CRUD operations

**Option B: As User**
- Email: `user@examhub.com`
- Password: `user123`
- Access: Course browsing, exam taking, subscriptions

### **Step 4: Load Sample Data (Optional)**

If you want to quickly test with pre-loaded data:

**Method 1: Browser Console**
1. Press `F12` to open Developer Tools
2. Go to "Console" tab
3. Paste and run:
```javascript
loadSampleData();
```

**Method 2: Uncomment in sample-data.js**
1. Open `sample-data.js`
2. Find the line: `// loadSampleData();`
3. Remove `//` to uncomment: `loadSampleData();`
4. Add script reference to `index.html` before closing `</body>` tag:
```html
<script src="sample-data.js"></script>
```

### **Step 5: Create Sample Data (Manual)**

**As Admin:**

#### **Create a Subject**
1. Login as admin
2. Click "Admin Dashboard"
3. Go to "Subjects" section
4. Fill form:
   - Subject Name: "Financial Accounting"
   - Subject Code: "FA"
   - Description: "Learn basics of accounting"
5. Click "Add Subject"

#### **Create a Course**
1. Go to "Courses" section
2. Fill form:
   - Course Name: "Accounting 101"
   - Subject: Select "Financial Accounting"
   - Course Fee: 2000
   - Reading Material: Leave blank (optional)
3. Click "Add Course"

#### **Create Questions**
1. Go to "Questions" section
2. Fill form:
   - Subject: "Financial Accounting"
   - Course: "Accounting 101"
   - Question: "What is an Asset?"
   - Type: MCQ
   - Options:
     * Option 1: "Resource with economic value"
     * Option 2: "Money in bank"
     * Option 3: "Inventory"
     * Option 4: "Equipment"
   - Select "Option 1" as correct answer
   - Complexity: Easy
3. Click "Add Question"
4. Repeat to add more questions (at least 3-5)

#### **Create an Assignment**
1. Go to "Assignments" section
2. Fill form:
   - Assignment Name: "Quiz 1"
   - Course: "Accounting 101"
   - Subject: "Financial Accounting"
   - Select Questions: Check the questions you created
   - Total Marks: 30 (or 10 × number of questions)
   - Duration: 30 (minutes)
3. Click "Create Assignment"

### **Step 6: Test as User**

#### **Enroll in Course**
1. Logout from admin account
2. Login as: `user@examhub.com` / `user123`
3. Click "Courses"
4. Click "Enroll Now" on a course
5. Confirm enrollment

#### **Subscribe to Plan**
1. Click "Subscription"
2. Choose a plan (Basic Rs. 500, Pro Rs. 1500, Premium Rs. 3500)
3. Click "Subscribe Now"
4. Confirm subscription

#### **Take an Exam**
1. Click "Exams"
2. Select an assignment
3. Click "Start Exam"
4. Answer questions:
   - MCQ: Select one option (radio button)
   - MTQ: Select multiple options (checkboxes)
5. Use Previous/Next to navigate
6. Click "Submit Exam" when done

#### **View Results**
- See results immediately after submission
- Click "Profile" to view exam history

### **Step 7: Troubleshooting**

#### **"Login Failed" Error**
- Check if email and password are correct
- Try clearing browser cache (Ctrl+Shift+Del)
- Reload page and try again

#### **Data Not Saving**
- Check if browser LocalStorage is enabled
- Not in private/incognito mode
- Check browser console for errors (F12)

#### **Questions Not Showing in Assignment**
- Make sure you selected at least 3 questions
- Check if questions belong to the same subject

#### **Exam Timer Issues**
- Refresh the page
- Check system time on computer
- Try different browser

### **Step 8: Advanced Setup**

#### **Export All Data**
1. Open browser console (F12)
2. Run:
```javascript
const data = db.exportData();
console.log(JSON.stringify(data, null, 2));
// Copy the output and save to a file
```

#### **Import Backup Data**
1. Have a backup JSON file ready
2. Open browser console
3. Run:
```javascript
const backupData = {...}; // Paste your backup data
db.importData(backupData);
```

#### **Clear All Data (WARNING!)**
1. Open browser console
2. Run:
```javascript
db.clearAll();
location.reload();
```

### **Step 9: Customize System**

#### **Change Logo/Title**
- Open `index.html`
- Find: `<h1>📚 ExamHub - MCQ Examination System</h1>`
- Change text as desired

#### **Change Colors**
- Open `styles.css`
- Find `:root` section
- Modify color variables:
```css
--primary-color: #2563eb;     /* Main color */
--secondary-color: #1e40af;   /* Secondary color */
--success-color: #10b981;     /* Success color */
--danger-color: #ef4444;      /* Error color */
```

#### **Change Subscription Plans**
- Open `user.js`
- Find `loadSubscriptionPlans()` function
- Modify the `plans` array with your pricing

### **Step 10: Share or Deploy**

#### **Local Network**
1. Note your computer's IP (e.g., 192.168.1.5)
2. Other computers on same network can access:
```
http://192.168.1.5/path/to/Online Exam/index.html
```

#### **Web Server (Apache, Nginx)**
1. Copy all files to web root
2. Access via: `http://yourdomain.com/Online Exam/`

#### **Cloud Hosting**
1. Upload files to hosting service (GitHub Pages, Netlify, Vercel)
2. Access via hosted URL

## 📋 Quick Checklist

- [ ] All files extracted to same directory
- [ ] Open index.html in browser
- [ ] Login with demo credentials
- [ ] Create at least 1 subject
- [ ] Create at least 1 course
- [ ] Create at least 5 questions
- [ ] Create 1 assignment with questions
- [ ] Logout and login as user
- [ ] Enroll in course
- [ ] Subscribe to plan
- [ ] Take and complete exam
- [ ] View results

## 🎓 Sample Flow for Testing

1. **Login as Admin** → Create Subject "Math"
2. **Create Course** "Algebra 101" in Math
3. **Create Questions** (MCQ & MTQ) about algebra
4. **Create Assignment** "Algebra Quiz" with 5 questions
5. **Logout** and Login as User
6. **Enroll** in "Algebra 101" course
7. **Subscribe** to Basic Plan (Rs. 500)
8. **Take Exam** "Algebra Quiz"
9. **Review Results** and Performance

## 🔍 File Descriptions

| File | Purpose |
|------|---------|
| `index.html` | Main HTML structure and UI |
| `styles.css` | All styling and layouts |
| `db.js` | Database operations (CRUD) |
| `auth.js` | Authentication and login |
| `admin.js` | Admin panel CRUD operations |
| `exam.js` | Exam logic and scoring |
| `user.js` | User dashboard and features |
| `app.js` | Main app logic and navigation |
| `sample-data.js` | Sample data for testing |

## 💡 Tips & Tricks

1. **Quick Test**: Load sample data to test all features immediately
2. **Multiple Users**: Open in different browser windows/tabs
3. **Reset Data**: Use `db.clearAll()` to start fresh
4. **Export Backups**: Regularly export and save your data
5. **Browser DevTools**: Use F12 console for debugging

## 📱 Mobile Testing

The system is responsive. Test on mobile by:
1. Chrome: DevTools → Device toolbar (Ctrl+Shift+M)
2. Firefox: Responsive Design Mode (Ctrl+Shift+M)
3. Or scan QR code on Android/iOS device

## ✅ Verification Checklist

After setup, verify these work:

- [ ] Login/Register functionality
- [ ] Subject CRUD operations
- [ ] Course CRUD operations
- [ ] Question CRUD operations
- [ ] Assignment creation
- [ ] Exam timer
- [ ] MCQ answers (single select)
- [ ] MTQ answers (multiple select)
- [ ] Score calculation
- [ ] Result display
- [ ] Subscription plans
- [ ] User profile
- [ ] Exam history
- [ ] Logout functionality

## 🆘 Getting Help

1. Check browser console for errors (F12)
2. Clear LocalStorage and refresh
3. Try in incognito/private mode
4. Check file paths are correct
5. Ensure all JS files are loaded (check Network tab)

## 🎉 You're All Set!

Start creating content and managing exams. Enjoy using ExamHub! 

For more details, see the main [README.md](README.md)
