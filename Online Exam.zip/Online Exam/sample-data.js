<!-- Sample Data Setup Script -->
<!-- Add this to the bottom of index.html before closing body tag -->
<!-- Or run these commands in browser console -->

<script>
// Sample Data for Quick Testing
function loadSampleData() {
    // Sample Subjects
    const subjects = [
        {
            name: "Financial Accounting",
            code: "FA",
            description: "Learn the fundamentals of financial accounting, balance sheet, income statement, and cash flow"
        },
        {
            name: "Cost Accounting",
            code: "CA",
            description: "Master cost accounting principles, costing methods, and cost analysis techniques"
        },
        {
            name: "Taxation",
            code: "TAX",
            description: "Understand tax laws, regulations, and best practices for tax planning"
        },
        {
            name: "Business Law",
            code: "BL",
            description: "Learn business law principles, contracts, and corporate governance"
        },
        {
            name: "Auditing",
            code: "AUD",
            description: "Master audit procedures, standards, and control mechanisms"
        }
    ];

    console.log("Adding sample subjects...");
    const subjectIds = subjects.map(s => {
        const subject = db.addSubject(s);
        console.log(`✓ Added: ${subject.name}`);
        return subject.id;
    });

    // Sample Courses
    const courses = [
        {
            name: "Financial Accounting Fundamentals",
            description: "Complete course on financial accounting basics, covering ledgers, journals, and financial statements.",
            subjectId: subjectIds[0],
            fee: 2000,
            readingMaterial: "https://example.com/fa-notes"
        },
        {
            name: "Advanced Financial Accounting",
            description: "Advanced topics in financial accounting including consolidation and IFRS standards.",
            subjectId: subjectIds[0],
            fee: 3000,
            readingMaterial: "https://example.com/advanced-fa"
        },
        {
            name: "Cost Accounting Masterclass",
            description: "Comprehensive course on costing methods, variance analysis, and management accounting.",
            subjectId: subjectIds[1],
            fee: 2500,
            readingMaterial: "https://example.com/ca-notes"
        },
        {
            name: "Tax Planning & Strategy",
            description: "Learn tax planning strategies, deductions, and compliance requirements.",
            subjectId: subjectIds[2],
            fee: 2000,
            readingMaterial: "https://example.com/tax-notes"
        },
        {
            name: "Auditing Standards & Procedures",
            description: "Complete guide to auditing standards, internal controls, and audit procedures.",
            subjectId: subjectIds[4],
            fee: 2500,
            readingMaterial: "https://example.com/audit-notes"
        }
    ];

    console.log("\nAdding sample courses...");
    const courseIds = courses.map(c => {
        const course = db.addCourse(c);
        console.log(`✓ Added: ${course.name}`);
        return course.id;
    });

    // Sample Questions
    const questions = [
        {
            text: "What does GAAP stand for?",
            subjectId: subjectIds[0],
            courseId: courseIds[0],
            type: "MCQ",
            options: [
                "Generally Accepted Accounting Principles",
                "Global Accounting and Auditing Procedures",
                "Governmental Accounting Assessment Program",
                "General Audit and Accounting Process"
            ],
            correctAnswers: [0],
            complexity: "Easy"
        },
        {
            text: "Which of the following are components of a Balance Sheet?",
            subjectId: subjectIds[0],
            courseId: courseIds[0],
            type: "MTQ",
            options: [
                "Assets",
                "Revenue",
                "Liabilities",
                "Expenses"
            ],
            correctAnswers: [0, 2],
            complexity: "Easy"
        },
        {
            text: "What is the accounting equation?",
            subjectId: subjectIds[0],
            courseId: courseIds[0],
            type: "MCQ",
            options: [
                "Assets = Liabilities + Equity",
                "Assets = Liabilities - Equity",
                "Assets + Liabilities = Equity",
                "Assets - Liabilities = Expenses"
            ],
            correctAnswers: [0],
            complexity: "Easy"
        },
        {
            text: "In cost accounting, which costing method is best for decision making?",
            subjectId: subjectIds[1],
            courseId: courseIds[2],
            type: "MCQ",
            options: [
                "Absorption Costing",
                "Marginal Costing",
                "Standard Costing",
                "Job Costing"
            ],
            correctAnswers: [1],
            complexity: "Medium"
        },
        {
            text: "Which of the following are methods of inventory valuation?",
            subjectId: subjectIds[1],
            courseId: courseIds[2],
            type: "MTQ",
            options: [
                "FIFO",
                "LIFO",
                "Weighted Average",
                "Historical Cost"
            ],
            correctAnswers: [0, 1, 2],
            complexity: "Medium"
        },
        {
            text: "What is the difference between revenue and profit?",
            subjectId: subjectIds[0],
            courseId: courseIds[1],
            type: "MCQ",
            options: [
                "Revenue is income minus expenses; Profit is total income",
                "Revenue is total income; Profit is income minus expenses",
                "They are the same thing",
                "Revenue is expense; Profit is income"
            ],
            correctAnswers: [1],
            complexity: "Medium"
        },
        {
            text: "A company has assets worth Rs. 500,000 and liabilities of Rs. 200,000. What is the equity?",
            subjectId: subjectIds[0],
            courseId: courseIds[0],
            type: "MCQ",
            options: [
                "Rs. 300,000",
                "Rs. 200,000",
                "Rs. 700,000",
                "Rs. 500,000"
            ],
            correctAnswers: [0],
            complexity: "Easy"
        },
        {
            text: "Which components are included in comprehensive income?",
            subjectId: subjectIds[0],
            courseId: courseIds[1],
            type: "MTQ",
            options: [
                "Net Profit",
                "Other Comprehensive Income",
                "Tax Expense",
                "Prior Period Adjustments"
            ],
            correctAnswers: [0, 1, 3],
            complexity: "Hard"
        },
        {
            text: "What is the primary purpose of an audit?",
            subjectId: subjectIds[4],
            courseId: courseIds[4],
            type: "MCQ",
            options: [
                "To detect fraud",
                "To express an opinion on the financial statements",
                "To find errors and fraud",
                "To minimize tax liability"
            ],
            correctAnswers: [1],
            complexity: "Easy"
        },
        {
            text: "Which of these are audit procedures?",
            subjectId: subjectIds[4],
            courseId: courseIds[4],
            type: "MTQ",
            options: [
                "Inspection",
                "Observation",
                "Taxation",
                "Recalculation"
            ],
            correctAnswers: [0, 1, 3],
            complexity: "Medium"
        }
    ];

    console.log("\nAdding sample questions...");
    const questionIds = questions.map(q => {
        const question = db.addQuestion(q);
        console.log(`✓ Added: ${question.text.substring(0, 50)}...`);
        return question.id;
    });

    // Sample Assignments
    const assignments = [
        {
            name: "Financial Accounting Quiz 1",
            courseId: courseIds[0],
            subjectId: subjectIds[0],
            questionIds: questionIds.slice(0, 3),
            totalMarks: 30,
            duration: 30,
            marksPerQuestion: 10
        },
        {
            name: "Cost Accounting Mid-Term",
            courseId: courseIds[2],
            subjectId: subjectIds[1],
            questionIds: questionIds.slice(3, 6),
            totalMarks: 30,
            duration: 45,
            marksPerQuestion: 10
        },
        {
            name: "Auditing Fundamentals",
            courseId: courseIds[4],
            subjectId: subjectIds[4],
            questionIds: questionIds.slice(8, 10),
            totalMarks: 20,
            duration: 30,
            marksPerQuestion: 10
        }
    ];

    console.log("\nAdding sample assignments...");
    assignments.forEach(a => {
        a.createdBy = auth.getCurrentUser().id;
        const assignment = db.addAssignment(a);
        console.log(`✓ Added: ${assignment.name}`);
    });

    console.log("\n✅ Sample data loaded successfully!");
    console.log("Total Subjects:", db.getAllSubjects().length);
    console.log("Total Courses:", db.getAllCourses().length);
    console.log("Total Questions:", db.getAllQuestions().length);
    console.log("Total Assignments:", db.getAllAssignments().length);
}

// Run sample data loader
// Uncomment the line below to automatically load sample data on page load
// loadSampleData();

// Or run manually in browser console: loadSampleData()
</script>
