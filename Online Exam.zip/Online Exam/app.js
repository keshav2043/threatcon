// Main Application Logic

function initializeApp() {
    const user = auth.getCurrentUser();
    
    if (!user) {
        showAuthModal();
        return;
    }

    // Show/hide admin menu based on role
    if (user.role === 'admin') {
        document.querySelectorAll('.admin-only').forEach(el => {
            el.style.display = 'block';
        });
    }

    // Load home page
    navigateToPage('home');
    updatePageStatistics();
}

function navigateToPage(pageName) {
    // Hide all pages
    document.querySelectorAll('.page').forEach(page => {
        page.style.display = 'none';
    });

    // Show selected page
    const page = document.getElementById(pageName);
    if (page) {
        page.style.display = 'block';

        // Load page-specific content
        if (pageName === 'courses') {
            loadCoursesPage();
        } else if (pageName === 'exams') {
            loadExamsPage();
        } else if (pageName === 'subscription') {
            loadSubscriptionPlans();
        } else if (pageName === 'profile') {
            loadUserProfile();
        } else if (pageName === 'home') {
            updatePageStatistics();
        }

        // Scroll to top
        window.scrollTo(0, 0);
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    
    // Add event listeners
    document.getElementById('questionType').addEventListener('change', updateCorrectAnswerOptions);
});

// Keyboard shortcuts
document.addEventListener('keydown', function(e) {
    if (currentExamData) {
        if (e.key === 'ArrowRight') {
            nextQuestion();
        } else if (e.key === 'ArrowLeft') {
            previousQuestion();
        }
    }
});
