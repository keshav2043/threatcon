# 📚 ExamHub - MCQ Online Examination System

A comprehensive, feature-rich MCQ (Multiple Choice Questions) and MTQ (Multiple True/False) online examination system with complete CRUD operations, subscription management, and course materials.

## 🌟 Features

### **1. Subject Management** ✅
- **Create** new subjects with code and descriptions
- **Read** all subjects with filtering capabilities
- **Update** subject information
- **Delete** subjects
- Subject-course linkage

### **2. Course Management** ✅
- **Create** courses linked to subjects
- **Read** courses with filters by subject
- **Update** course details and pricing
- **Delete** courses
- Reading material URLs integration
- Course fee management

### **3. Question Management** ✅
- **Create** MCQ and MTQ questions
- **Read** questions with filters by subject and course
- **Update** question content and answers
- **Delete** questions
- Complexity levels (Easy, Medium, Hard)
- Multiple correct answers for MTQ
- Single correct answer for MCQ

### **4. MCQ/MTQ Assignment Module** ✅
- **Create** assignments from existing questions
- **Read** all assignments
- **Update** assignment details
- **Delete** assignments
- Link assignments to courses and subjects
- Configurable total marks
- Configurable duration
- Complexity-based question selection

### **5. MCQ Exam Attendance** ✅
- **Take exams** with timer
- **Navigate** between questions
- **Mark** answers for MCQ and MTQ
- **Submit** exam with automatic scoring
- **View results** immediately
- Detailed answer review
- Complexity level display

### **6. User Subscription Module** ✅
- **Three-tier pricing** plans:
  - Basic Plan: Rs. 500 / 30 days
  - Pro Plan: Rs. 1500 / 90 days
  - Premium Plan: Rs. 3500 / 365 days (Lifetime)
- **Subscribe** to plans
- **Manage** subscription expiry
- **Track** subscription status
- **Payment** recording

### **7. User Dashboard** ✅
- **Profile** management
- **Exam history** with scores and percentages
- **Enrolled courses** tracking
- **Subscription** status display
- **Performance** analytics

### **8. Courses & Reading Materials** ✅
- **Access** enrolled courses
- **Download** or **view** reading materials
- **Material links** integrated with courses
- **Course search** and filtering

### **9. User Authentication** ✅
- **Register** new accounts
- **Login** with email and password
- **Secure** password storage (hashed)
- **Role-based** access (User/Admin)
- **Session** management

## 🏗️ System Architecture

### **Database Schema**
```
Database: LocalStorage (JSON)
├── Subjects
│   ├── id, name, code, description, createdAt
├── Courses
│   ├── id, name, description, subjectId, fee, readingMaterial, enrolled, createdAt
├── Questions
│   ├── id, text, subjectId, courseId, type, options, correctAnswers, complexity, createdAt
├── Assignments
│   ├── id, name, courseId, subjectId, questionIds, totalMarks, duration, marksPerQuestion, createdAt
├── ExamResponses
│   ├── id, assignmentId, userId, answers, score, percentage, status, startTime, endTime
├── Users
│   ├── id, email, password, name, role, subscriptionStatus, enrolledCourses, createdAt
├── Subscriptions
│   ├── id, userId, plan, startDate, expiryDate, active, paymentId, createdAt
└── Payments
    └── id, userId, planId, amount, timestamp
```

## 🚀 Getting Started

### **Prerequisites**
- Modern web browser (Chrome, Firefox, Safari, Edge)
- No server required (runs entirely on client-side)

### **Installation**

1. **Extract the files** to your web server or local directory
2. **Open** `index.html` in your browser
3. **System automatically initializes** with demo data

### **Demo Credentials**

**Admin Account:**
- Email: `admin@examhub.com`
- Password: `admin123`

**User Account:**
- Email: `user@examhub.com`
- Password: `user123`

## 📖 Usage Guide

### **For Administrators**

#### **Access Admin Dashboard**
1. Login with admin credentials
2. Click "Admin Dashboard" in navbar
3. Select the module you want to manage

#### **Subject Management**
1. Navigate to **Subjects** section
2. **Add Subject**: Fill subject name, code, and description
3. **Edit Subject**: Click Edit button, modify, and update
4. **Delete Subject**: Click Delete button

#### **Course Management**
1. Navigate to **Courses** section
2. **Add Course**: Select subject, enter name, fee, and reading material URL
3. **Edit Course**: Click Edit, modify details
4. **Delete Course**: Click Delete

#### **Question Management**
1. Navigate to **Questions** section
2. **Add Question**:
   - Select subject and course
   - Enter question text
   - Choose MCQ or MTQ type
   - Enter 4 options
   - Select correct answer(s)
   - Set complexity level
3. **Edit Question**: Click Edit to modify
4. **Delete Question**: Click Delete

#### **Assignment Management**
1. Navigate to **Assignments** section
2. **Create Assignment**:
   - Enter assignment name
   - Select course and subject
   - Select questions from the list
   - Set total marks and duration
   - Click "Create Assignment"
3. **Delete Assignment**: Click Delete

#### **User Management**
1. Navigate to **Users** section
2. **View** all registered users
3. **Deactivate/Activate** user accounts
4. **Monitor** subscription status

### **For Users**

#### **Register & Login**
1. Click "Register" tab in login modal
2. Fill name, email, and password
3. Click "Register"
4. Login with credentials

#### **Explore Courses**
1. Click "Courses" in navbar
2. **Search** courses by name
3. **Filter** by subject
4. Click "Enroll Now" to join

#### **View Reading Materials**
1. On courses page, click "View Materials"
2. Opens reading material in new window

#### **Subscribe to Plans**
1. Click "Subscription" in navbar
2. Choose a plan (Basic, Pro, or Premium)
3. Click "Subscribe Now"
4. Confirm subscription

#### **Take an Exam**
1. Click "Exams" in navbar
2. Choose an available exam
3. Click "Start Exam"
4. Answer MCQ/MTQ questions:
   - MCQ: Select one option
   - MTQ: Select multiple options
5. Use **Previous/Next** buttons to navigate
6. Click "Submit Exam" to finish
7. View results immediately

#### **Check Results & History**
1. Click "Profile" in navbar
2. View:
   - Personal information
   - Subscription status
   - Exam history with scores
   - Performance details

## 🎯 Key Features Explained

### **MCQ (Multiple Choice Questions)**
- Only ONE correct answer
- Radio buttons for selection
- Automatic validation

### **MTQ (Multiple True/False Questions)**
- MULTIPLE correct answers possible
- Checkboxes for selection
- Must match all correct answers for full marks

### **Complexity Levels**
- **Easy**: Basic questions
- **Medium**: Intermediate questions
- **Hard**: Advanced questions
- Marked during exam display

### **Scoring System**
- Equal marks per question
- Formula: `(Correct Answers × Marks per Question) / Total Marks × 100`
- Pass threshold: 60%
- Instant result display

### **Timer Feature**
- Real-time countdown
- Turns red when less than 1 minute remaining
- Auto-submit at 0 seconds

### **Progress Tracking**
- Question counter
- Visited question tracking
- Answer status display

## 📊 Data Management

### **Data Storage**
- All data stored in **LocalStorage**
- Persists across browser sessions
- No server required
- Maximum size: ~5-10MB per domain

### **Export Data**
- Available through browser console:
```javascript
// Export all data
const data = db.exportData();
console.log(JSON.stringify(data, null, 2));
```

### **Import Data**
```javascript
// Import data
db.importData(exportedData);
```

### **Clear All Data**
```javascript
// WARNING: Irreversible
db.clearAll();
```

## 🔐 Security Notes

### **Current Implementation**
- Demo uses Base64 password encoding (NOT SECURE for production)
- All data in browser memory/localStorage

### **For Production**
Implement:
1. HTTPS encryption
2. bcrypt or similar for passwords
3. JWT tokens
4. Backend authentication
5. Database encryption
6. Rate limiting
7. CSRF protection
8. SQL injection prevention

## 🎨 Customization

### **Change Color Scheme**
Edit `styles.css` CSS variables:
```css
:root {
    --primary-color: #2563eb;  /* Change primary color */
    --secondary-color: #1e40af;  /* Change secondary color */
    --success-color: #10b981;  /* Change success color */
    /* ... more colors ... */
}
```

### **Add New Subjects**
Use Admin Dashboard Subjects section

### **Modify Questions**
Use Admin Dashboard Questions section

### **Change Subscription Plans**
Edit `user.js` in `loadSubscriptionPlans()` function

## 📱 Responsive Design

The system is fully responsive and works on:
- Desktop computers
- Tablets
- Mobile devices (portrait & landscape)

## 🔧 Browser Compatibility

| Browser | Version | Support |
|---------|---------|---------|
| Chrome  | 90+     | ✅ Full |
| Firefox | 88+     | ✅ Full |
| Safari  | 14+     | ✅ Full |
| Edge    | 90+     | ✅ Full |
| IE      | 11      | ❌ No   |

## 🐛 Troubleshooting

### **Login Not Working**
- Check browser cookies are enabled
- Clear browser cache and try again
- Open in incognito mode

### **Data Not Saving**
- Check if LocalStorage is enabled
- Not in private/incognito mode
- Browser has sufficient storage space

### **Timer Not Working**
- Close other heavy applications
- Check browser console for errors
- Refresh page

### **Exam Submission Failed**
- Ensure all questions are attempted
- Check internet connection
- Refresh page if stuck

## 📚 File Structure

```
Online Exam/
├── index.html          # Main HTML file
├── styles.css          # All styling
├── db.js              # Database layer
├── auth.js            # Authentication logic
├── admin.js           # Admin CRUD operations
├── exam.js            # Exam management
├── user.js            # User features
├── app.js             # Main app logic
└── README.md          # This file
```

## 🚀 Future Enhancements

- [ ] Backend database integration (MySQL/MongoDB)
- [ ] Real payment gateway integration
- [ ] Email notifications
- [ ] Progress analytics dashboard
- [ ] Certificate generation
- [ ] Mobile app
- [ ] Question banks with tagging
- [ ] Negative marking
- [ ] Shuffle options
- [ ] Question randomization
- [ ] Bulk upload (CSV)
- [ ] Performance reports
- [ ] Leaderboard
- [ ] Discussion forum
- [ ] Video lectures integration

## 📞 Support

For issues or questions:
1. Check browser console for errors (F12)
2. Verify data in LocalStorage
3. Try clearing cache and reloading
4. Check browser compatibility

## 📄 License

This is a demo educational project. Feel free to modify and use for learning purposes.

## 👨‍💻 Developer Info

**Project**: MCQ Online Examination System
**Type**: Educational Platform
**Technology**: HTML5, CSS3, JavaScript (Vanilla)
**Storage**: Browser LocalStorage
**Last Updated**: May 2026

---

## ✨ Quick Start Checklist

- [ ] Extract all files to a folder
- [ ] Open `index.html` in browser
- [ ] Login with demo credentials
- [ ] Create a subject (as admin)
- [ ] Create a course (as admin)
- [ ] Create questions (as admin)
- [ ] Create an assignment (as admin)
- [ ] Login as user
- [ ] Enroll in course
- [ ] Subscribe to plan
- [ ] Take an exam
- [ ] View results

---

**Happy Learning! 📚**

For more information, visit the project repository or contact the development team.
