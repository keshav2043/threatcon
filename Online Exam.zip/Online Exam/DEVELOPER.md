# 📖 ExamHub - Developer Documentation

## API Reference & Database Operations

### **Database API (db.js)**

All database operations are accessible through the global `db` object.

#### **Subject Operations**

```javascript
// Add a new subject
db.addSubject({
    name: "Subject Name",
    code: "CODE",
    description: "Description"
});

// Get all subjects
db.getAllSubjects();

// Get subject by ID
db.getSubjectById(id);

// Update subject
db.updateSubject(id, {
    name: "New Name",
    description: "New Description"
});

// Delete subject
db.deleteSubject(id);
```

#### **Course Operations**

```javascript
// Add a new course
db.addCourse({
    name: "Course Name",
    description: "Description",
    subjectId: "subject_id",
    fee: 2000,
    readingMaterial: "url"
});

// Get all courses
db.getAllCourses();

// Get course by ID
db.getCourseById(id);

// Get courses by subject
db.getCoursesBySubject(subjectId);

// Update course
db.updateCourse(id, {
    name: "New Name",
    fee: 3000
});

// Delete course
db.deleteCourse(id);
```

#### **Question Operations**

```javascript
// Add a new question
db.addQuestion({
    text: "Question text?",
    subjectId: "subject_id",
    courseId: "course_id",
    type: "MCQ", // or "MTQ"
    options: ["Option 1", "Option 2", "Option 3", "Option 4"],
    correctAnswers: [0], // MCQ: array with 1 index, MTQ: multiple indices
    complexity: "Easy" // "Easy", "Medium", "Hard"
});

// Get all questions
db.getAllQuestions();

// Get question by ID
db.getQuestionById(id);

// Get questions by subject
db.getQuestionsBySubject(subjectId);

// Get questions by course
db.getQuestionsByCourse(courseId);

// Get questions by complexity
db.getQuestionsByComplexity("Hard");

// Update question
db.updateQuestion(id, {
    text: "Updated question?",
    correctAnswers: [1, 3]
});

// Delete question
db.deleteQuestion(id);
```

#### **Assignment Operations**

```javascript
// Add a new assignment
db.addAssignment({
    name: "Assignment Name",
    courseId: "course_id",
    subjectId: "subject_id",
    questionIds: ["q1", "q2", "q3"],
    totalMarks: 100,
    duration: 60, // minutes
    marksPerQuestion: 10
});

// Get all assignments
db.getAllAssignments();

// Get assignment by ID
db.getAssignmentById(id);

// Get assignments by course
db.getAssignmentsByCourse(courseId);

// Get assignments by subject
db.getAssignmentsBySubject(subjectId);

// Update assignment
db.updateAssignment(id, {
    name: "New Name",
    totalMarks: 150
});

// Delete assignment
db.deleteAssignment(id);
```

#### **User Operations**

```javascript
// Get all users
db.getAllUsers();

// Get user by ID
db.getUserById(id);

// Get user by email
db.getUserByEmail("email@example.com");

// Update user
db.updateUser(id, {
    name: "New Name",
    enrolledCourses: ["course1", "course2"]
});
```

#### **Exam Response Operations**

```javascript
// Save exam response
db.saveExamResponse({
    assignmentId: "assignment_id",
    userId: "user_id",
    answers: {...},
    score: 75,
    percentage: 75,
    status: "PASS"
});

// Get user's exam responses
db.getUserExamResponses(userId);

// Get responses for specific assignment
db.getExamResponsesByAssignment(assignmentId);
```

#### **Subscription Operations**

```javascript
// Add subscription
db.addSubscription({
    userId: "user_id",
    plan: "pro", // "basic", "pro", "premium"
    startDate: new Date().toISOString(),
    expiryDate: future_date,
    active: true
});

// Get user's active subscription
db.getUserSubscription(userId);

// Get all subscriptions
db.getAllSubscriptions();
```

#### **Payment Operations**

```javascript
// Record payment
db.recordPayment({
    userId: "user_id",
    planId: "plan_id",
    amount: 1500,
    status: "completed"
});

// Get user's payments
db.getUserPayments(userId);
```

#### **Utility Functions**

```javascript
// Get database statistics
db.getStatistics();
// Returns: {
//     totalSubjects,
//     totalCourses,
//     totalQuestions,
//     totalAssignments,
//     totalUsers,
//     activeSubscriptions,
//     totalRevenue
// }

// Search courses
db.searchCourses("accounting");

// Search questions
db.searchQuestions("asset");

// Export all data
const data = db.exportData();

// Import data
db.importData(data);

// Clear all data (WARNING!)
db.clearAll();
```

---

### **Authentication API (auth.js)**

```javascript
// Register new user
auth.register(email, password, name);
// Returns: { success: true/false, message, user }

// Login user
auth.login(email, password);
// Returns: { success: true/false, message, user }

// Logout
auth.logout();

// Get current user
auth.getCurrentUser();
// Returns: user object or null

// Check if logged in
auth.isLoggedIn();

// Check if admin
auth.isAdmin();

// Update profile
auth.updateProfile(userId, updates);
// Returns: updated user object

// Create demo accounts
auth.createDemoAccounts();
```

---

### **Admin API (admin.js)**

#### **Subject Management**

```javascript
// Add subject
addSubject();

// Load subjects
loadSubjects();

// Edit subject
editSubject(id);

// Delete subject
deleteSubjectConfirm(id);

// Clear form
clearSubjectForm();
```

#### **Course Management**

```javascript
// Add course
addCourse();

// Load courses
loadCourses();

// Populate subject select
populateSubjectSelect();

// Edit course
editCourse(id);

// Delete course
deleteCourseConfirm(id);

// Clear form
clearCourseForm();
```

#### **Question Management**

```javascript
// Add question
addQuestion();

// Load questions
loadQuestions();

// Populate question subjects
populateQuestionSubjects();

// Populate question courses
populateQuestionCourses();

// Update correct answer options
updateCorrectAnswerOptions();

// Edit question
editQuestion(id);

// Delete question
deleteQuestionConfirm(id);

// Clear form
clearQuestionForm();
```

#### **Assignment Management**

```javascript
// Create assignment
createAssignment();

// Load assignments
loadAssignments();

// Populate assignment selects
populateAssignmentSelects();

// Load assignment questions
loadAssignmentQuestions();

// Delete assignment
deleteAssignmentConfirm(id);

// Clear form
clearAssignmentForm();
```

---

### **Exam API (exam.js)**

```javascript
// Start exam
startExam(assignmentId);

// Load exam question
loadExamQuestion();

// Select answer
selectAnswer(optionIndex);

// Navigate to next question
nextQuestion();

// Navigate to previous question
previousQuestion();

// Update timer display
updateTimerDisplay();

// Finish exam
finishExam();

// Calculate results
calculateResults();
// Returns: { score, totalMarks, percentage, status, correct, wrong, skipped, detailedResults }

// Show results
showResults(response, results);
```

---

### **User API (user.js)**

```javascript
// Load courses page
loadCoursesPage();

// Filter courses
filterCourses();

// Enroll in course
enrollCourse(courseId);

// View reading material
viewReadingMaterial(materialUrl);

// Load exams page
loadExamsPage();

// Load subscription plans
loadSubscriptionPlans();

// Subscribe to plan
subscribePlan(planId, planName, price);

// Load user profile
loadUserProfile();

// Update page statistics
updatePageStatistics();
```

---

### **Application API (app.js)**

```javascript
// Initialize application
initializeApp();

// Navigate to page
navigateToPage(pageName);
// Pages: 'home', 'admin', 'courses', 'exams', 'subscription', 'profile'
```

---

## Data Models

### **Subject**
```javascript
{
    id: "subject_timestamp_random",
    name: "Subject Name",
    code: "CODE",
    description: "Description",
    isActive: true,
    createdAt: "ISO_DATE",
    updatedAt: "ISO_DATE" // optional
}
```

### **Course**
```javascript
{
    id: "course_timestamp_random",
    name: "Course Name",
    description: "Description",
    subjectId: "subject_id",
    fee: 2000,
    readingMaterial: "url",
    isActive: true,
    enrolled: [],
    createdAt: "ISO_DATE"
}
```

### **Question**
```javascript
{
    id: "question_timestamp_random",
    text: "Question text?",
    subjectId: "subject_id",
    courseId: "course_id",
    type: "MCQ", // or "MTQ"
    options: ["Option 1", "Option 2", "Option 3", "Option 4"],
    correctAnswers: [0], // array of indices
    complexity: "Easy", // "Easy", "Medium", "Hard"
    isActive: true,
    createdAt: "ISO_DATE"
}
```

### **Assignment**
```javascript
{
    id: "assignment_timestamp_random",
    name: "Assignment Name",
    courseId: "course_id",
    subjectId: "subject_id",
    questionIds: ["q1", "q2", "q3"],
    totalMarks: 100,
    duration: 60,
    marksPerQuestion: 10,
    isActive: true,
    createdBy: "user_id",
    createdAt: "ISO_DATE"
}
```

### **User**
```javascript
{
    id: "user_timestamp_random",
    email: "user@example.com",
    password: "hashed_password",
    name: "User Name",
    role: "user", // or "admin"
    active: true,
    subscriptionStatus: "free", // or plan name
    enrolledCourses: ["course1", "course2"],
    profileCompleted: false,
    createdAt: "ISO_DATE"
}
```

### **ExamResponse**
```javascript
{
    id: "response_timestamp_random",
    assignmentId: "assignment_id",
    userId: "user_id",
    answers: {
        0: { questionId: "q1", type: "MCQ", selected: 2, visited: true },
        1: { questionId: "q2", type: "MTQ", selected: [0, 2], visited: true }
    },
    score: 75,
    totalMarks: 100,
    percentage: 75,
    status: "PASS",
    correctCount: 3,
    wrongCount: 2,
    skipped: 0,
    startTime: "ISO_DATE",
    endTime: "ISO_DATE",
    submittedAt: "ISO_DATE"
}
```

### **Subscription**
```javascript
{
    id: "subscription_timestamp_random",
    userId: "user_id",
    plan: "pro", // "basic", "pro", "premium"
    startDate: "ISO_DATE",
    expiryDate: "ISO_DATE",
    active: true,
    paymentId: "payment_id",
    createdAt: "ISO_DATE"
}
```

### **Payment**
```javascript
{
    id: "payment_timestamp_random",
    userId: "user_id",
    planId: "plan_id",
    amount: 1500,
    status: "completed",
    timestamp: "ISO_DATE"
}
```

---

## Event Listeners & Hooks

### **Available Events**

```javascript
// Add to DOMContentLoaded
document.addEventListener('DOMContentLoaded', function() {
    // App initialized
});

// Keyboard shortcuts
document.addEventListener('keydown', function(e) {
    // During exam:
    // Arrow Right -> Next Question
    // Arrow Left -> Previous Question
});
```

---

## Custom Functions & Extensions

### **Example: Add a new page**

1. Add HTML section in `index.html`:
```html
<div id="newpage" class="page">
    <h2>New Page</h2>
    <!-- content -->
</div>
```

2. Add navigation link:
```html
<li><a href="#" onclick="navigateToPage('newpage')">New Page</a></li>
```

3. Add initialization function in `app.js`:
```javascript
if (pageName === 'newpage') {
    loadNewPageContent();
}
```

### **Example: Add a new admin section**

1. Add HTML in admin panel
2. Add functions for CRUD operations
3. Call `showAdminSection('newsection')` to display

### **Example: Custom scoring**

Edit `exam.js` `calculateResults()` function to implement custom logic:
```javascript
function calculateResults() {
    let score = 0;
    // Custom scoring logic
    return { score, percentage, status, ... };
}
```

---

## localStorage Structure

Access localStorage directly:

```javascript
// Get full database
const db_content = localStorage.getItem('examhub_db');
const data = JSON.parse(db_content);

// Direct manipulation (not recommended)
data.subjects.push({...});
localStorage.setItem('examhub_db', JSON.stringify(data));

// Get current user
const currentUser = localStorage.getItem('currentUser');
```

---

## Browser Console Debugging

```javascript
// Check database status
console.log(db.getStatistics());

// View all users
console.log(db.getAllUsers());

// View all data
console.log(db.exportData());

// Check current user
console.log(auth.getCurrentUser());

// Test email exists
console.log(db.getUserByEmail("user@examhub.com"));

// Get exam responses for user
console.log(db.getUserExamResponses("user_id"));

// Calculate average score
const responses = db.getExamResponsesByAssignment("assignment_id");
const avgScore = responses.reduce((a,b) => a + b.score, 0) / responses.length;
console.log("Average Score:", avgScore);
```

---

## Performance Tips

1. **Limit questions per assignment**: 30-50 maximum
2. **Optimize images**: Use URLs instead of embedded images
3. **Cache data**: Use `db.getStatistics()` instead of calculating each time
4. **Limit user lists**: Implement pagination for large user bases
5. **Export backups**: Regular exports to manage localStorage size

---

## Security Considerations

### **Current Implementation**
- Base64 password encoding (NOT SECURE)
- All data in browser memory

### **For Production**
1. Implement backend authentication
2. Use HTTPS/TLS
3. Hash passwords with bcrypt
4. Implement JWT tokens
5. Validate all inputs
6. Sanitize HTML/SQL
7. Add rate limiting
8. Implement CSRF protection
9. Use secure cookies
10. Add user activity logging

---

## Migration to Backend

To migrate to a backend database:

1. Replace `db.js` with API calls
2. Update all `db.*` calls to fetch/POST requests
3. Move authentication to backend
4. Store session tokens in localStorage
5. Implement proper error handling
6. Add request validation
7. Implement database constraints

Example:
```javascript
// Replace
db.addSubject(subject);

// With
const response = await fetch('/api/subjects', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(subject)
});
const result = await response.json();
```

---

## Contributing

To add new features:
1. Follow existing code patterns
2. Add data model to `db.js`
3. Add CRUD operations to `db.js`
4. Add UI in `index.html`
5. Add logic in appropriate `*.js` file
6. Test thoroughly
7. Update this documentation

---

## Troubleshooting Development

### **Changes not reflecting**
- Clear browser cache (Ctrl+Shift+Del)
- Check console for errors (F12)
- Reload page completely (Ctrl+F5)

### **Data integrity issues**
- Export current data as backup
- Clear data and reimport
- Check for console errors

### **Performance issues**
- Check number of records
- Monitor localStorage size
- Profile with browser DevTools

---

For more information, see [README.md](README.md) and [SETUP.md](SETUP.md)
