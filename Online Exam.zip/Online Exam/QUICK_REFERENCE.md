# 🎯 ExamHub - Quick Reference Guide

## 🚀 Getting Started (5 Minutes)

### **Step 1: Open Application**
1. Extract all files to a folder
2. Open `index.html` in your browser
3. System initializes automatically

### **Step 2: Login**

**As Admin:**
```
Email: admin@examhub.com
Password: admin123
```

**As User:**
```
Email: user@examhub.com
Password: user123
```

### **Step 3: Test Features**
1. Create a subject
2. Create a course
3. Create questions
4. Create an assignment
5. Take an exam as user

---

## 📚 Feature Quick Guide

### **Admin Dashboard**

| Task | Steps |
|------|-------|
| **Add Subject** | Admin Dashboard → Subjects → Fill form → Add Subject |
| **Add Course** | Admin Dashboard → Courses → Select subject → Fill form → Add Course |
| **Add Question** | Admin Dashboard → Questions → Select subject/course → Fill form → Add Question |
| **Create Assignment** | Admin Dashboard → Assignments → Select questions → Set marks → Create Assignment |
| **View Users** | Admin Dashboard → Users → See all users |

### **User Features**

| Task | Steps |
|------|-------|
| **Browse Courses** | Courses → Search/Filter → View courses |
| **Enroll Course** | Courses → Click "Enroll Now" |
| **Subscribe Plan** | Subscription → Choose plan → Subscribe Now |
| **Take Exam** | Exams → Select exam → Start Exam |
| **View Results** | Exams → See previous scores OR Profile |
| **See History** | Profile → View exam history |

---

## 🎓 Question Types

### **MCQ (Multiple Choice)**
- Select **ONE** answer only
- Radio buttons
- Full marks if correct

### **MTQ (Multiple True/False)**
- Select **MULTIPLE** answers
- Checkboxes
- Full marks if all correct

---

## ⏱️ Exam Features

| Feature | Description |
|---------|-------------|
| **Timer** | Countdown in top right |
| **Question Counter** | Shows "Q 1 of 10" |
| **Navigation** | Previous/Next buttons |
| **Submit** | Submit Exam button at end |
| **Auto-Save** | Answers saved automatically |
| **Auto-Submit** | Exam submits at time end |

---

## 💰 Subscription Plans

| Plan | Price | Duration | Best For |
|------|-------|----------|----------|
| Basic | Rs. 500 | 30 days | Casual learners |
| Pro | Rs. 1500 | 90 days | Regular students |
| Premium | Rs. 3500 | 365 days | Serious students |

---

## 🎯 Complexity Levels

- **Easy** 🟢 - Basic concepts
- **Medium** 🟡 - Intermediate topics
- **Hard** 🔴 - Advanced topics

---

## 📊 Scoring Formula

```
Marks Obtained = Correct Answers × Marks per Question
Percentage = (Marks Obtained / Total Marks) × 100
Status = PASS if Percentage ≥ 60%
```

### **Example**
```
10 Questions, 10 marks each = 100 total
Correct: 7 questions = 70 marks
Percentage: (70/100) × 100 = 70%
Status: PASS ✓
```

---

## 🔑 Keyboard Shortcuts (During Exam)

| Key | Action |
|-----|--------|
| **←** | Previous Question |
| **→** | Next Question |
| **F12** | Open Developer Tools |
| **Ctrl+S** | Save (auto-saved anyway) |

---

## 🐛 Troubleshooting Quick Fixes

| Problem | Solution |
|---------|----------|
| Login fails | Clear cache (Ctrl+Shift+Del) → Reload |
| Data missing | Not in private mode? → Enable LocalStorage |
| Timer not working | Refresh page → Try another browser |
| Can't submit exam | Answer all questions (or use submit button) |
| Slow performance | Close other tabs → Restart browser |

---

## 📱 Browser Support

| Browser | Supported |
|---------|-----------|
| Chrome | ✅ Yes |
| Firefox | ✅ Yes |
| Safari | ✅ Yes |
| Edge | ✅ Yes |
| IE 11 | ❌ No |

---

## 🔒 Password Tips

- Use strong passwords (8+ characters)
- Mix uppercase, lowercase, numbers
- Don't share passwords
- Remember your email and password

**Demo passwords are for testing only.**

---

## 💡 Pro Tips

1. **Load Sample Data**: Open console (F12) → `loadSampleData()`
2. **Export Backup**: Console → Copy output from `db.exportData()`
3. **Test Quickly**: Use keyboard arrows to navigate exam
4. **Multiple Users**: Open in different browser windows
5. **Clear Data**: Use `db.clearAll()` to reset everything

---

## 📂 File Overview

```
index.html          - Main app interface
styles.css          - All styling
db.js              - Database (CRUD)
auth.js            - Login system
admin.js           - Admin features
exam.js            - Exam logic
user.js            - User features
app.js             - Main app logic
```

---

## 🎬 Typical Workflow

```
ADMIN WORKFLOW:
Login as Admin
  ↓
Create Subject (e.g., Math)
  ↓
Create Course (e.g., Algebra)
  ↓
Create Questions (MCQ/MTQ)
  ↓
Create Assignment
  ↓
Logout

USER WORKFLOW:
Login as User
  ↓
Browse Courses
  ↓
Enroll in Course
  ↓
Subscribe to Plan (if needed)
  ↓
Take Exam
  ↓
View Results
  ↓
Check History
```

---

## 📈 Performance

| Metric | Value |
|--------|-------|
| Page load | < 2 seconds |
| Exam start | < 1 second |
| Score calculation | Instant |
| Data size limit | ~5-10MB |
| Max users | No limit |
| Max courses | No limit |

---

## 🎨 Customization

### **Change Colors**
Edit `styles.css`:
```css
--primary-color: #2563eb;  /* Change this */
--success-color: #10b981;  /* And this */
```

### **Change Plan Prices**
Edit `user.js` `loadSubscriptionPlans()` function

### **Change Logo**
Edit `index.html` find `<h1>` tag and change text

---

## 🆘 Quick Help Links

| Topic | Solution |
|-------|----------|
| Can't login | Check credentials, clear cache |
| Data not saved | Enable LocalStorage |
| Slow exam | Close other apps, refresh |
| Exam won't start | Check course enrollment |
| Results wrong | Check question answers |

---

## 📞 Common Questions

### **Q: Where is my data stored?**
A: Browser LocalStorage (on your computer)

### **Q: Can I access from different computers?**
A: No, data is local. Export and import on another computer.

### **Q: How do I back up data?**
A: Console → `db.exportData()` → Save to file

### **Q: Can I delete exam responses?**
A: Clear all data with `db.clearAll()` then reload

### **Q: Is this secure?**
A: For demo/learning only. Not for production.

### **Q: How many questions can I add?**
A: Unlimited (limited by browser storage)

### **Q: Can I retake exams?**
A: Yes, unlimited attempts

### **Q: What happens if timer runs out?**
A: Exam auto-submits with current answers

---

## ✅ Verification Checklist

- [ ] Page loads without errors
- [ ] Can login with demo account
- [ ] Can see admin dashboard (as admin)
- [ ] Can create subject
- [ ] Can create course
- [ ] Can create question
- [ ] Can create assignment
- [ ] Can logout and login as user
- [ ] Can enroll in course
- [ ] Can subscribe to plan
- [ ] Can take exam
- [ ] Can see results
- [ ] Can view profile

---

## 🎯 Next Steps

1. ✅ Explore all features
2. ✅ Create sample content
3. ✅ Take a test exam
4. ✅ Customize for your needs
5. ✅ Deploy/Share with others

---

## 🚀 Deployment

### **Local Use**
- Just open HTML file

### **Network Sharing**
- Put on network drive or web server
- Share URL with others

### **Cloud Hosting**
- Upload to GitHub Pages, Netlify, etc.
- Share hosted URL

---

## 📚 Documentation Links

- **Full Documentation**: [README.md](README.md)
- **Setup Instructions**: [SETUP.md](SETUP.md)
- **Developer API**: [DEVELOPER.md](DEVELOPER.md)
- **Project Summary**: [PROJECT_SUMMARY.md](PROJECT_SUMMARY.md)

---

## ⏰ Time Estimates

| Task | Time |
|------|------|
| Setup | 1 min |
| First login | 1 min |
| Create subject | 2 min |
| Create course | 3 min |
| Create 10 questions | 15 min |
| Create assignment | 2 min |
| Take exam | 5 min |
| View results | 1 min |

**Total Setup to First Exam: ~30 minutes**

---

## 🏆 Best Practices

1. ✅ Back up data regularly
2. ✅ Use strong passwords
3. ✅ Clear old assignments
4. ✅ Review question content
5. ✅ Test exams before use
6. ✅ Update question bank
7. ✅ Monitor user performance
8. ✅ Track system statistics

---

## 🎓 Learning Path

### **Day 1: Setup**
- Extract files
- Login
- Explore interface

### **Day 2: Admin**
- Create subjects
- Add courses
- Add questions

### **Day 3: Testing**
- Create assignment
- Login as user
- Take exam

### **Day 4: Deploy**
- Customize
- Share with others
- Monitor usage

---

## 🎁 Bonus Features

✨ Keyboard navigation
✨ Mobile responsive
✨ Search and filter
✨ Statistics dashboard
✨ Exam history
✨ Reading materials
✨ Sample data loader
✨ Data export/import

---

## 📞 Support Resources

1. Console error messages (F12)
2. Browser developer tools
3. Check documentation files
4. Review sample data
5. Test with demo accounts

---

## 🎉 You're Ready!

Everything is set up and ready to use. Start with the quick workflow above.

**Happy Learning! 📚**

---

*For detailed information, see the full documentation files.*
