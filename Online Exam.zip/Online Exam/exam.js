// Exam Module - Taking Exams and Results

let currentExam = null;
let currentExamData = null;
let examStartTime = null;
let examResponses = {};
let currentQuestionIndex = 0;

function startExam(assignmentId) {
    const assignment = db.getAssignmentById(assignmentId);
    if (!assignment) {
        alert('Assignment not found');
        return;
    }

    currentExam = assignment;
    currentExamData = {
        assignmentId: assignmentId,
        userId: auth.getCurrentUser().id,
        startTime: new Date().toISOString(),
        questions: assignment.questionIds.map(qId => db.getQuestionById(qId)).filter(q => q)
    };

    if (currentExamData.questions.length === 0) {
        alert('No questions in this assignment');
        return;
    }

    examStartTime = Date.now();
    examResponses = {};
    currentQuestionIndex = 0;

    // Initialize responses object
    currentExamData.questions.forEach((q, idx) => {
        examResponses[idx] = {
            questionId: q.id,
            type: q.type,
            selected: q.type === 'MTQ' ? [] : null,
            visited: false
        };
    });

    navigateToPage('exam-interface');
    loadExamQuestion();
}

function loadExamQuestion() {
    if (!currentExamData || currentQuestionIndex >= currentExamData.questions.length) {
        return;
    }

    const question = currentExamData.questions[currentQuestionIndex];
    const response = examResponses[currentQuestionIndex];

    document.getElementById('examTitle').textContent = currentExam.name;
    document.getElementById('questionNumber').textContent = 
        `Question ${currentQuestionIndex + 1} of ${currentExamData.questions.length}`;

    let optionsHTML = question.options.map((opt, idx) => {
        const isSelected = response.type === 'MCQ' ? 
            response.selected === idx : 
            response.selected.includes(idx);

        return `
            <label class="option-label">
                <input 
                    type="${response.type === 'MCQ' ? 'radio' : 'checkbox'}" 
                    name="option" 
                    value="${idx}"
                    ${isSelected ? 'checked' : ''}
                    onchange="selectAnswer(${idx})">
                <span>${opt}</span>
            </label>
        `;
    }).join('');

    document.getElementById('exam-content').innerHTML = `
        <div class="question-container">
            <div class="question-text">
                <strong>Q${currentQuestionIndex + 1}:</strong> ${question.text}
            </div>
            <div class="complexity-badge">Complexity: <span>${question.complexity}</span></div>
            <div class="options-list">
                ${optionsHTML}
            </div>
            <div class="question-meta">
                <span>Marks: ${currentExam.marksPerQuestion}</span>
                <span>Type: ${question.type}</span>
            </div>
        </div>
    `;

    updateTimerDisplay();
    response.visited = true;
}

function selectAnswer(optionIndex) {
    const response = examResponses[currentQuestionIndex];
    
    if (response.type === 'MCQ') {
        response.selected = optionIndex;
    } else {
        if (response.selected.includes(optionIndex)) {
            response.selected = response.selected.filter(i => i !== optionIndex);
        } else {
            response.selected.push(optionIndex);
        }
    }
}

function nextQuestion() {
    if (currentQuestionIndex < currentExamData.questions.length - 1) {
        currentQuestionIndex++;
        loadExamQuestion();
    } else {
        alert('This is the last question');
    }
}

function previousQuestion() {
    if (currentQuestionIndex > 0) {
        currentQuestionIndex--;
        loadExamQuestion();
    } else {
        alert('This is the first question');
    }
}

function updateTimerDisplay() {
    const remainingMs = (currentExam.duration * 60 * 1000) - (Date.now() - examStartTime);
    
    if (remainingMs <= 0) {
        finishExam();
        return;
    }

    const minutes = Math.floor(remainingMs / 60000);
    const seconds = Math.floor((remainingMs % 60000) / 1000);

    const timerElement = document.getElementById('timeRemaining');
    if (timerElement) {
        timerElement.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
        if (remainingMs < 60000) {
            timerElement.style.color = 'red';
        }
    }

    setTimeout(updateTimerDisplay, 1000);
}

function finishExam() {
    if (!confirm('Are you sure you want to submit the exam?')) {
        return;
    }

    const results = calculateResults();
    const response = {
        assignmentId: currentExam.id,
        userId: auth.getCurrentUser().id,
        startTime: currentExamData.startTime,
        endTime: new Date().toISOString(),
        answers: examResponses,
        score: results.score,
        totalMarks: currentExam.totalMarks,
        percentage: results.percentage,
        status: results.status,
        correctCount: results.correct,
        wrongCount: results.wrong,
        skipped: results.skipped
    };

    db.saveExamResponse(response);
    showResults(response, results);
}

function calculateResults() {
    let correct = 0;
    let wrong = 0;
    let skipped = 0;
    let detailedResults = [];

    currentExamData.questions.forEach((question, idx) => {
        const response = examResponses[idx];
        const correctAnswers = question.correctAnswers;
        
        let isCorrect = false;

        if (response.type === 'MCQ') {
            isCorrect = response.selected === correctAnswers[0];
        } else {
            isCorrect = response.selected.length === correctAnswers.length &&
                response.selected.every(a => correctAnswers.includes(a));
        }

        if (response.selected === null || response.selected.length === 0) {
            skipped++;
        } else if (isCorrect) {
            correct++;
        } else {
            wrong++;
        }

        detailedResults.push({
            questionId: question.id,
            question: question.text,
            type: question.type,
            correctAnswers: correctAnswers.map(i => question.options[i]),
            userAnswers: response.type === 'MCQ' ?
                (response.selected !== null ? [question.options[response.selected]] : []) :
                response.selected.map(i => question.options[i]),
            isCorrect,
            complexity: question.complexity
        });
    });

    const totalMarks = currentExam.totalMarks;
    const marksPerQuestion = currentExam.marksPerQuestion;
    const score = correct * marksPerQuestion;
    const percentage = Math.round((score / totalMarks) * 100);
    const status = percentage >= 60 ? 'PASS' : 'FAIL';

    return {
        score,
        totalMarks,
        percentage,
        status,
        correct,
        wrong,
        skipped,
        detailedResults
    };
}

function showResults(response, results) {
    navigateToPage('exam-results');
    
    document.getElementById('examTitleResult').textContent = currentExam.name;
    document.getElementById('finalScore').textContent = `${response.score}/${response.totalMarks}`;
    document.getElementById('percentageScore').textContent = `${response.percentage}%`;
    document.getElementById('statusResult').textContent = response.status;
    document.getElementById('statusResult').className = 
        response.status === 'PASS' ? 'pass' : 'fail';

    const detailsHTML = results.detailedResults.map((r, idx) => `
        <div class="result-item ${r.isCorrect ? 'correct' : 'incorrect'}">
            <h4>Question ${idx + 1}</h4>
            <p class="question-text">${r.question}</p>
            <div class="result-details">
                <p><strong>Type:</strong> ${r.type} | <strong>Complexity:</strong> ${r.complexity}</p>
                <p><strong>Correct Answer(s):</strong> ${r.correctAnswers.join(' | ')}</p>
                <p><strong>Your Answer:</strong> ${r.userAnswers.length > 0 ? r.userAnswers.join(' | ') : 'Not Answered'}</p>
                <p><strong>Status:</strong> ${r.isCorrect ? '✅ Correct' : '❌ Incorrect'}</p>
            </div>
        </div>
    `).join('');

    const summaryHTML = `
        <div class="results-summary-stats">
            <div class="stat">
                <span class="stat-label">Correct Answers</span>
                <span class="stat-value correct">${results.correct}</span>
            </div>
            <div class="stat">
                <span class="stat-label">Wrong Answers</span>
                <span class="stat-value incorrect">${results.wrong}</span>
            </div>
            <div class="stat">
                <span class="stat-label">Skipped Questions</span>
                <span class="stat-value skipped">${results.skipped}</span>
            </div>
        </div>
    `;

    document.getElementById('results-details').innerHTML = summaryHTML + detailsHTML;

    // Save to user profile
    const user = auth.getCurrentUser();
    user.examHistory = user.examHistory || [];
    user.examHistory.push(response);
    auth.updateProfile(user.id, user);

    currentExam = null;
    currentExamData = null;
}
