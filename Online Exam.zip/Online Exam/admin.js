// Admin Module - CRUD Operations

function showAdminSection(section) {
    document.querySelectorAll('.admin-section').forEach(s => s.style.display = 'none');
    document.getElementById(`${section}-section`).style.display = 'block';
    
    if (section === 'subjects') {
        loadSubjects();
    } else if (section === 'courses') {
        loadCourses();
        populateSubjectSelect();
    } else if (section === 'questions') {
        loadQuestions();
        populateQuestionSubjects();
    } else if (section === 'assignments') {
        loadAssignments();
        populateAssignmentSelects();
    } else if (section === 'userassignments') {
        loadUserAssignmentsSection();
    } else if (section === 'users') {
        loadUsers();
    }
}

// ========== SUBJECT OPERATIONS ==========

function addSubject() {
    const name = document.getElementById('subjectName').value;
    const desc = document.getElementById('subjectDesc').value;
    const code = document.getElementById('subjectCode').value;
    
    if (!name || !code) {
        alert('Please fill all required fields');
        return;
    }
    
    db.addSubject({
        name,
        description: desc,
        code,
        isActive: true
    });
    
    clearSubjectForm();
    loadSubjects();
    alert('Subject added successfully!');
}

function loadSubjects() {
    const subjects = db.getAllSubjects();
    const container = document.getElementById('subjects-list');
    
    if (subjects.length === 0) {
        container.innerHTML = '<p>No subjects found. Add a new subject.</p>';
        return;
    }
    
    container.innerHTML = subjects.map(subject => `
        <div class="list-item">
            <div class="list-item-content">
                <h4>${subject.name}</h4>
                <p>${subject.description}</p>
                <span class="badge">Code: ${subject.code}</span>
            </div>
            <div class="list-item-actions">
                <button onclick="editSubject('${subject.id}')" class="btn btn-sm btn-secondary">Edit</button>
                <button onclick="deleteSubjectConfirm('${subject.id}')" class="btn btn-sm btn-danger">Delete</button>
            </div>
        </div>
    `).join('');
}

function editSubject(id) {
    const subject = db.getSubjectById(id);
    if (subject) {
        document.getElementById('subjectName').value = subject.name;
        document.getElementById('subjectDesc').value = subject.description;
        document.getElementById('subjectCode').value = subject.code;
        
        // Add update functionality
        const btn = document.querySelector('#subjects-section button');
        btn.textContent = 'Update Subject';
        btn.onclick = () => {
            db.updateSubject(id, {
                name: document.getElementById('subjectName').value,
                description: document.getElementById('subjectDesc').value,
                code: document.getElementById('subjectCode').value
            });
            btn.textContent = 'Add Subject';
            btn.onclick = addSubject;
            clearSubjectForm();
            loadSubjects();
            alert('Subject updated successfully!');
        };
    }
}

function deleteSubjectConfirm(id) {
    if (confirm('Are you sure you want to delete this subject?')) {
        db.deleteSubject(id);
        loadSubjects();
        alert('Subject deleted successfully!');
    }
}

function clearSubjectForm() {
    document.getElementById('subjectName').value = '';
    document.getElementById('subjectDesc').value = '';
    document.getElementById('subjectCode').value = '';
}

// ========== COURSE OPERATIONS ==========

function populateSubjectSelect() {
    const subjects = db.getAllSubjects();
    const select = document.getElementById('courseSubject');
    select.innerHTML = '<option value="">Select Subject</option>' + 
        subjects.map(s => `<option value="${s.id}">${s.name}</option>`).join('');
}

function addCourse() {
    const name = document.getElementById('courseName').value;
    const desc = document.getElementById('courseDesc').value;
    const subjectId = document.getElementById('courseSubject').value;
    const fee = parseFloat(document.getElementById('courseFee').value);
    const readMaterial = document.getElementById('courseReadMaterial').value;
    
    if (!name || !subjectId) {
        alert('Please fill all required fields');
        return;
    }
    
    db.addCourse({
        name,
        description: desc,
        subjectId,
        fee: fee || 0,
        readingMaterial: readMaterial,
        isActive: true
    });
    
    clearCourseForm();
    loadCourses();
    alert('Course added successfully!');
}

function loadCourses() {
    const courses = db.getAllCourses();
    const container = document.getElementById('courses-list');
    
    if (courses.length === 0) {
        container.innerHTML = '<p>No courses found. Add a new course.</p>';
        return;
    }
    
    container.innerHTML = courses.map(course => {
        const subject = db.getSubjectById(course.subjectId);
        return `
            <div class="list-item">
                <div class="list-item-content">
                    <h4>${course.name}</h4>
                    <p>${course.description}</p>
                    <span class="badge">Subject: ${subject ? subject.name : 'N/A'}</span>
                    <span class="badge">Fee: Rs. ${course.fee}</span>
                    ${course.readingMaterial ? `<span class="badge">📚 Reading Material</span>` : ''}
                </div>
                <div class="list-item-actions">
                    <button onclick="editCourse('${course.id}')" class="btn btn-sm btn-secondary">Edit</button>
                    <button onclick="deleteCourseConfirm('${course.id}')" class="btn btn-sm btn-danger">Delete</button>
                </div>
            </div>
        `;
    }).join('');
}

function editCourse(id) {
    const course = db.getCourseById(id);
    if (course) {
        document.getElementById('courseName').value = course.name;
        document.getElementById('courseDesc').value = course.description;
        document.getElementById('courseSubject').value = course.subjectId;
        document.getElementById('courseFee').value = course.fee;
        document.getElementById('courseReadMaterial').value = course.readingMaterial || '';
        
        const btn = document.querySelector('#courses-section button[onclick="addCourse()"]');
        if (btn) {
            btn.textContent = 'Update Course';
            btn.onclick = () => {
                db.updateCourse(id, {
                    name: document.getElementById('courseName').value,
                    description: document.getElementById('courseDesc').value,
                    subjectId: document.getElementById('courseSubject').value,
                    fee: parseFloat(document.getElementById('courseFee').value),
                    readingMaterial: document.getElementById('courseReadMaterial').value
                });
                btn.textContent = 'Add Course';
                btn.onclick = addCourse;
                clearCourseForm();
                loadCourses();
                alert('Course updated successfully!');
            };
        }
    }
}

function deleteCourseConfirm(id) {
    if (confirm('Are you sure you want to delete this course?')) {
        db.deleteCourse(id);
        loadCourses();
        alert('Course deleted successfully!');
    }
}

function clearCourseForm() {
    document.getElementById('courseName').value = '';
    document.getElementById('courseDesc').value = '';
    document.getElementById('courseSubject').value = '';
    document.getElementById('courseFee').value = '';
    document.getElementById('courseReadMaterial').value = '';
}

// ========== QUESTION OPERATIONS ==========

function populateQuestionSubjects() {
    const subjects = db.getAllSubjects();
    const select = document.getElementById('questionSubject');
    select.innerHTML = '<option value="">Select Subject</option>' + 
        subjects.map(s => `<option value="${s.id}">${s.name}</option>`).join('');
    
    select.onchange = () => populateQuestionCourses();
}

function populateQuestionCourses() {
    const subjectId = document.getElementById('questionSubject').value;
    const courses = db.getCoursesBySubject(subjectId);
    const select = document.getElementById('questionCourse');
    select.innerHTML = '<option value="">Select Course</option>' + 
        courses.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
}

function updateCorrectAnswerOptions() {
    const container = document.getElementById('correct-options');
    const type = document.getElementById('questionType').value;
    const options = [
        document.getElementById('option1').value || 'Option 1',
        document.getElementById('option2').value || 'Option 2',
        document.getElementById('option3').value || 'Option 3',
        document.getElementById('option4').value || 'Option 4'
    ];
    
    if (type === 'MCQ') {
        container.innerHTML = options.map((opt, idx) => `
            <label>
                <input type="radio" name="correct" value="${idx}"> ${opt}
            </label>
        `).join('');
    } else {
        container.innerHTML = options.map((opt, idx) => `
            <label>
                <input type="checkbox" name="correct" value="${idx}"> ${opt}
            </label>
        `).join('');
    }
}

function addQuestion() {
    const subjectId = document.getElementById('questionSubject').value;
    const courseId = document.getElementById('questionCourse').value;
    const text = document.getElementById('questionText').value;
    const type = document.getElementById('questionType').value;
    const complexity = document.getElementById('questionComplexity').value;
    
    if (!subjectId || !courseId || !text) {
        alert('Please fill all required fields');
        return;
    }
    
    const correctAnswers = [];
    if (type === 'MCQ') {
        const checked = document.querySelector('input[name="correct"]:checked');
        if (!checked) {
            alert('Please select the correct answer');
            return;
        }
        correctAnswers.push(parseInt(checked.value));
    } else {
        const checked = document.querySelectorAll('input[name="correct"]:checked');
        if (checked.length === 0) {
            alert('Please select at least one correct answer');
            return;
        }
        checked.forEach(c => correctAnswers.push(parseInt(c.value)));
    }
    
    const options = [
        document.getElementById('option1').value,
        document.getElementById('option2').value,
        document.getElementById('option3').value,
        document.getElementById('option4').value
    ];
    
    if (options.some(o => !o)) {
        alert('Please fill all options');
        return;
    }
    
    db.addQuestion({
        text,
        subjectId,
        courseId,
        type,
        options,
        correctAnswers,
        complexity,
        isActive: true
    });
    
    clearQuestionForm();
    loadQuestions();
    alert('Question added successfully!');
}

function loadQuestions() {
    const questions = db.getAllQuestions();
    const container = document.getElementById('questions-list');
    
    if (questions.length === 0) {
        container.innerHTML = '<p>No questions found. Add a new question.</p>';
        return;
    }
    
    container.innerHTML = questions.map(q => {
        const subject = db.getSubjectById(q.subjectId);
        const course = db.getCourseById(q.courseId);
        return `
            <div class="list-item">
                <div class="list-item-content">
                    <h4>${q.text.substring(0, 60)}...</h4>
                    <p>Type: ${q.type} | Complexity: ${q.complexity}</p>
                    <span class="badge">${subject ? subject.name : 'N/A'}</span>
                    <span class="badge">${course ? course.name : 'N/A'}</span>
                    <p class="options">Options: ${q.options.join(' | ')}</p>
                </div>
                <div class="list-item-actions">
                    <button onclick="editQuestion('${q.id}')" class="btn btn-sm btn-secondary">Edit</button>
                    <button onclick="deleteQuestionConfirm('${q.id}')" class="btn btn-sm btn-danger">Delete</button>
                </div>
            </div>
        `;
    }).join('');
}

function editQuestion(id) {
    const question = db.getQuestionById(id);
    if (question) {
        document.getElementById('questionSubject').value = question.subjectId;
        populateQuestionCourses();
        setTimeout(() => {
            document.getElementById('questionCourse').value = question.courseId;
        }, 100);
        document.getElementById('questionText').value = question.text;
        document.getElementById('questionType').value = question.type;
        document.getElementById('option1').value = question.options[0];
        document.getElementById('option2').value = question.options[1];
        document.getElementById('option3').value = question.options[2];
        document.getElementById('option4').value = question.options[3];
        document.getElementById('questionComplexity').value = question.complexity;
        updateCorrectAnswerOptions();
    }
}

function deleteQuestionConfirm(id) {
    if (confirm('Are you sure you want to delete this question?')) {
        db.deleteQuestion(id);
        loadQuestions();
        alert('Question deleted successfully!');
    }
}

function clearQuestionForm() {
    document.getElementById('questionSubject').value = '';
    document.getElementById('questionCourse').value = '';
    document.getElementById('questionText').value = '';
    document.getElementById('option1').value = '';
    document.getElementById('option2').value = '';
    document.getElementById('option3').value = '';
    document.getElementById('option4').value = '';
    document.getElementById('correct-options').innerHTML = '';
}

// ========== ASSIGNMENT OPERATIONS ==========

function populateAssignmentSelects() {
    const subjects = db.getAllSubjects();
    const courses = db.getAllCourses();
    
    const subjectSelect = document.getElementById('assignmentSubject');
    const courseSelect = document.getElementById('assignmentCourse');
    
    subjectSelect.innerHTML = '<option value="">Select Subject</option>' + 
        subjects.map(s => `<option value="${s.id}">${s.name}</option>`).join('');
    
    courseSelect.innerHTML = '<option value="">Select Course</option>' + 
        courses.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
    
    subjectSelect.onchange = loadAssignmentQuestions;
}

function loadAssignmentQuestions() {
    const subjectId = document.getElementById('assignmentSubject').value;
    const questions = db.getQuestionsBySubject(subjectId);
    const container = document.getElementById('assignment-questions');
    
    container.innerHTML = questions.map(q => `
        <label class="checkbox-item">
            <input type="checkbox" value="${q.id}" class="question-checkbox">
            <span>${q.text.substring(0, 80)}... (${q.complexity})</span>
        </label>
    `).join('');
}

function createAssignment() {
    const name = document.getElementById('assignmentName').value;
    const courseId = document.getElementById('assignmentCourse').value;
    const subjectId = document.getElementById('assignmentSubject').value;
    const totalMarks = parseInt(document.getElementById('assignmentTotalMarks').value);
    const duration = parseInt(document.getElementById('assignmentDuration').value);
    
    const selectedQuestions = Array.from(document.querySelectorAll('.question-checkbox:checked'))
        .map(cb => cb.value);
    
    if (!name || !courseId || !subjectId || selectedQuestions.length === 0) {
        alert('Please fill all required fields and select at least one question');
        return;
    }
    
    db.addAssignment({
        name,
        courseId,
        subjectId,
        questionIds: selectedQuestions,
        totalMarks,
        duration,
        marksPerQuestion: totalMarks / selectedQuestions.length,
        isActive: true,
        createdBy: auth.getCurrentUser().id
    });
    
    clearAssignmentForm();
    loadAssignments();
    alert('Assignment created successfully!');
}

function loadAssignments() {
    const assignments = db.getAllAssignments();
    const container = document.getElementById('assignments-list');
    
    if (assignments.length === 0) {
        container.innerHTML = '<p>No assignments found. Create a new assignment.</p>';
        return;
    }
    
    container.innerHTML = assignments.map(a => {
        const course = db.getCourseById(a.courseId);
        const subject = db.getSubjectById(a.subjectId);
        return `
            <div class="list-item">
                <div class="list-item-content">
                    <h4>${a.name}</h4>
                    <p>Course: ${course ? course.name : 'N/A'} | Subject: ${subject ? subject.name : 'N/A'}</p>
                    <span class="badge">Questions: ${a.questionIds.length}</span>
                    <span class="badge">Total Marks: ${a.totalMarks}</span>
                    <span class="badge">Duration: ${a.duration} mins</span>
                </div>
                <div class="list-item-actions">
                    <button onclick="deleteAssignmentConfirm('${a.id}')" class="btn btn-sm btn-danger">Delete</button>
                </div>
            </div>
        `;
    }).join('');
}

function deleteAssignmentConfirm(id) {
    if (confirm('Are you sure you want to delete this assignment?')) {
        db.deleteAssignment(id);
        loadAssignments();
        alert('Assignment deleted successfully!');
    }
}

function clearAssignmentForm() {
    document.getElementById('assignmentName').value = '';
    document.getElementById('assignmentCourse').value = '';
    document.getElementById('assignmentSubject').value = '';
    document.getElementById('assignmentTotalMarks').value = '100';
    document.getElementById('assignmentDuration').value = '60';
    document.getElementById('assignment-questions').innerHTML = '';
}

// ========== USER MANAGEMENT ==========

function loadUsers() {
    const users = db.getAllUsers();
    const container = document.getElementById('users-list');
    
    if (users.length === 0) {
        container.innerHTML = '<p>No users found.</p>';
        return;
    }
    
    container.innerHTML = users.map(user => {
        const subscription = db.getUserSubscription(user.id);
        return `
            <div class="list-item">
                <div class="list-item-content">
                    <h4>${user.name}</h4>
                    <p>Email: ${user.email}</p>
                    <span class="badge">Role: ${user.role}</span>
                    <span class="badge">Status: ${user.active ? 'Active' : 'Inactive'}</span>
                    <span class="badge">Subscription: ${subscription ? subscription.plan : 'None'}</span>
                </div>
                <div class="list-item-actions">
                    <button onclick="toggleUserStatus('${user.id}')" class="btn btn-sm btn-secondary">
                        ${user.active ? 'Deactivate' : 'Activate'}
                    </button>
                </div>
            </div>
        `;
    }).join('');
}

function toggleUserStatus(userId) {
    const user = db.getUserById(userId);
    if (user) {
        db.updateUser(userId, { active: !user.active });
        loadUsers();
    }
}

// ========== USER ASSIGNMENT OPERATIONS ==========

function loadUserAssignmentsSection() {
    populateUserAssignmentSelects();
    loadUserAssignmentsList();
}

function populateUserAssignmentSelects() {
    const subjects = db.getAllSubjects();
    const users = db.getAllUsers();
    
    const subjectSelect = document.getElementById('assignUserSubject');
    const userSelect = document.getElementById('assignUserUser');
    
    subjectSelect.innerHTML = '<option value="">Select Subject</option>' + 
        subjects.map(s => `<option value="${s.id}">${s.name}</option>`).join('');
    
    userSelect.innerHTML = '<option value="">Select User</option>' + 
        users.filter(u => u.role === 'user')
            .map(u => `<option value="${u.id}">${u.name} (${u.email})</option>`).join('');
}

function createMixedAssignmentForUser() {
    const subjectId = document.getElementById('assignUserSubject').value;
    const userId = document.getElementById('assignUserUser').value;
    const assignmentName = document.getElementById('mixedAssignmentName').value;
    const questionCount = parseInt(document.getElementById('mixedQuestionCount').value) || 10;
    const complexity = document.getElementById('mixedComplexity').value;
    const totalMarks = parseInt(document.getElementById('mixedTotalMarks').value) || 100;
    const duration = parseInt(document.getElementById('mixedDuration').value) || 60;
    
    if (!subjectId || !userId || !assignmentName) {
        alert('Please fill all required fields');
        return;
    }
    
    const subject = db.getSubjectById(subjectId);
    
    // Get mixed questions
    let questionIds;
    if (complexity === 'mixed') {
        const mixedQuestions = db.getMixedQuestionsByComplexityDistribution(subjectId, questionCount);
        questionIds = mixedQuestions.map(q => q.id);
    } else {
        const mixedQuestions = db.getMixedQuestionsByComplexity(subjectId, complexity, questionCount);
        questionIds = mixedQuestions.map(q => q.id);
    }
    
    if (questionIds.length === 0) {
        alert(`No questions found in subject "${subject.name}" with selected criteria`);
        return;
    }
    
    // Create a temporary assignment
    const tempAssignment = db.addAssignment({
        name: assignmentName,
        courseId: '',
        subjectId: subjectId,
        questionIds: questionIds,
        totalMarks: totalMarks,
        duration: duration,
        marksPerQuestion: totalMarks / questionIds.length,
        isActive: true,
        createdBy: auth.getCurrentUser().id,
        isMixed: true
    });
    
    // Assign to user
    db.addUserAssignment({
        userId: userId,
        assignmentId: tempAssignment.id,
        subjectId: subjectId,
        assignedAt: new Date().toISOString(),
        status: 'pending'
    });
    
    clearMixedAssignmentForm();
    loadUserAssignmentsList();
    alert(`✅ Assignment "${assignmentName}" assigned to user successfully!\n\nQuestions: ${questionIds.length}\nFrom Subject: ${subject.name}`);
}

function clearMixedAssignmentForm() {
    document.getElementById('assignUserSubject').value = '';
    document.getElementById('assignUserUser').value = '';
    document.getElementById('mixedAssignmentName').value = '';
    document.getElementById('mixedQuestionCount').value = '10';
    document.getElementById('mixedComplexity').value = 'mixed';
    document.getElementById('mixedTotalMarks').value = '100';
    document.getElementById('mixedDuration').value = '60';
}

function loadUserAssignmentsList() {
    const assignments = db.getAllUserAssignments();
    const container = document.getElementById('user-assignments-list');
    
    if (assignments.length === 0) {
        container.innerHTML = '<p>No user assignments yet. Create one above.</p>';
        return;
    }
    
    container.innerHTML = assignments.map(a => {
        const user = db.getUserById(a.userId);
        const assignment = db.getAssignmentById(a.assignmentId);
        const subject = db.getSubjectById(a.subjectId);
        
        return `
            <div class="list-item">
                <div class="list-item-content">
                    <h4>${assignment ? assignment.name : 'N/A'}</h4>
                    <p>User: <strong>${user ? user.name : 'N/A'}</strong> (${user ? user.email : 'N/A'})</p>
                    <p>Subject: ${subject ? subject.name : 'N/A'}</p>
                    <p>Status: <span class="badge">${a.status}</span></p>
                    ${assignment ? `<p>Questions: ${assignment.questionIds.length} | Marks: ${assignment.totalMarks} | Duration: ${assignment.duration}m</p>` : ''}
                    <p style="font-size: 0.85rem; color: #6b7280;">Assigned: ${new Date(a.assignedAt).toLocaleString()}</p>
                </div>
                <div class="list-item-actions">
                    <button onclick="deleteUserAssignmentConfirm('${a.id}')" class="btn btn-sm btn-danger">Remove</button>
                </div>
            </div>
        `;
    }).join('');
}

function deleteUserAssignmentConfirm(id) {
    if (confirm('Are you sure you want to remove this assignment from user?')) {
        db.deleteUserAssignment(id);
        loadUserAssignmentsList();
        alert('Assignment removed successfully!');
    }
}
