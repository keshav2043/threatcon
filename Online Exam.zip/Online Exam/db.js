// Database Management System
// Using LocalStorage with JSON serialization

class Database {
    constructor() {
        this.dbName = 'examhub_db';
        this.initializeDB();
    }

    initializeDB() {
        if (!localStorage.getItem(this.dbName)) {
            localStorage.setItem(this.dbName, JSON.stringify({
                subjects: [],
                courses: [],
                questions: [],
                assignments: [],
                examResponses: [],
                users: [],
                subscriptions: [],
                payments: []
            }));
        }
    }

    getDB() {
        return JSON.parse(localStorage.getItem(this.dbName));
    }

    saveDB(data) {
        localStorage.setItem(this.dbName, JSON.stringify(data));
    }

    // Subject Operations
    addSubject(subject) {
        const db = this.getDB();
        subject.id = this.generateId('subject');
        subject.createdAt = new Date().toISOString();
        db.subjects.push(subject);
        this.saveDB(db);
        return subject;
    }

    updateSubject(id, updates) {
        const db = this.getDB();
        const subject = db.subjects.find(s => s.id === id);
        if (subject) {
            Object.assign(subject, updates);
            subject.updatedAt = new Date().toISOString();
            this.saveDB(db);
            return subject;
        }
        return null;
    }

    deleteSubject(id) {
        const db = this.getDB();
        db.subjects = db.subjects.filter(s => s.id !== id);
        this.saveDB(db);
    }

    getAllSubjects() {
        return this.getDB().subjects;
    }

    getSubjectById(id) {
        return this.getDB().subjects.find(s => s.id === id);
    }

    // Course Operations
    addCourse(course) {
        const db = this.getDB();
        course.id = this.generateId('course');
        course.createdAt = new Date().toISOString();
        course.enrolled = [];
        db.courses.push(course);
        this.saveDB(db);
        return course;
    }

    updateCourse(id, updates) {
        const db = this.getDB();
        const course = db.courses.find(c => c.id === id);
        if (course) {
            Object.assign(course, updates);
            course.updatedAt = new Date().toISOString();
            this.saveDB(db);
            return course;
        }
        return null;
    }

    deleteCourse(id) {
        const db = this.getDB();
        db.courses = db.courses.filter(c => c.id !== id);
        this.saveDB(db);
    }

    getAllCourses() {
        return this.getDB().courses;
    }

    getCourseById(id) {
        return this.getDB().courses.find(c => c.id === id);
    }

    getCoursesBySubject(subjectId) {
        return this.getDB().courses.filter(c => c.subjectId === subjectId);
    }

    // Question Operations
    addQuestion(question) {
        const db = this.getDB();
        question.id = this.generateId('question');
        question.createdAt = new Date().toISOString();
        db.questions.push(question);
        this.saveDB(db);
        return question;
    }

    updateQuestion(id, updates) {
        const db = this.getDB();
        const question = db.questions.find(q => q.id === id);
        if (question) {
            Object.assign(question, updates);
            question.updatedAt = new Date().toISOString();
            this.saveDB(db);
            return question;
        }
        return null;
    }

    deleteQuestion(id) {
        const db = this.getDB();
        db.questions = db.questions.filter(q => q.id !== id);
        this.saveDB(db);
    }

    getAllQuestions() {
        return this.getDB().questions;
    }

    getQuestionById(id) {
        return this.getDB().questions.find(q => q.id === id);
    }

    getQuestionsBySubject(subjectId) {
        return this.getDB().questions.filter(q => q.subjectId === subjectId);
    }

    getQuestionsByCourse(courseId) {
        return this.getDB().questions.filter(q => q.courseId === courseId);
    }

    getQuestionsByComplexity(complexity) {
        return this.getDB().questions.filter(q => q.complexity === complexity);
    }

    // Assignment Operations
    addAssignment(assignment) {
        const db = this.getDB();
        assignment.id = this.generateId('assignment');
        assignment.createdAt = new Date().toISOString();
        db.assignments.push(assignment);
        this.saveDB(db);
        return assignment;
    }

    updateAssignment(id, updates) {
        const db = this.getDB();
        const assignment = db.assignments.find(a => a.id === id);
        if (assignment) {
            Object.assign(assignment, updates);
            assignment.updatedAt = new Date().toISOString();
            this.saveDB(db);
            return assignment;
        }
        return null;
    }

    deleteAssignment(id) {
        const db = this.getDB();
        db.assignments = db.assignments.filter(a => a.id !== id);
        this.saveDB(db);
    }

    getAllAssignments() {
        return this.getDB().assignments;
    }

    getAssignmentById(id) {
        return this.getDB().assignments.find(a => a.id === id);
    }

    getAssignmentsByCourse(courseId) {
        return this.getDB().assignments.filter(a => a.courseId === courseId);
    }

    getAssignmentsBySubject(subjectId) {
        return this.getDB().assignments.filter(a => a.subjectId === subjectId);
    }

    // User Operations
    addUser(user) {
        const db = this.getDB();
        user.id = this.generateId('user');
        user.createdAt = new Date().toISOString();
        user.subscriptionStatus = 'free';
        user.enrolledCourses = [];
        db.users.push(user);
        this.saveDB(db);
        return user;
    }

    updateUser(id, updates) {
        const db = this.getDB();
        const user = db.users.find(u => u.id === id);
        if (user) {
            Object.assign(user, updates);
            user.updatedAt = new Date().toISOString();
            this.saveDB(db);
            return user;
        }
        return null;
    }

    getUserByEmail(email) {
        return this.getDB().users.find(u => u.email === email);
    }

    getUserById(id) {
        return this.getDB().users.find(u => u.id === id);
    }

    getAllUsers() {
        return this.getDB().users;
    }

    // Exam Responses Operations
    saveExamResponse(response) {
        const db = this.getDB();
        response.id = this.generateId('response');
        response.submittedAt = new Date().toISOString();
        db.examResponses.push(response);
        this.saveDB(db);
        return response;
    }

    getUserExamResponses(userId) {
        return this.getDB().examResponses.filter(r => r.userId === userId);
    }

    getExamResponsesByAssignment(assignmentId) {
        return this.getDB().examResponses.filter(r => r.assignmentId === assignmentId);
    }

    // Subscription Operations
    addSubscription(subscription) {
        const db = this.getDB();
        subscription.id = this.generateId('subscription');
        subscription.createdAt = new Date().toISOString();
        db.subscriptions.push(subscription);
        this.saveDB(db);
        return subscription;
    }

    getUserSubscription(userId) {
        const db = this.getDB();
        return db.subscriptions.find(s => s.userId === userId && s.active);
    }

    getAllSubscriptions() {
        return this.getDB().subscriptions;
    }

    // Payment Operations
    recordPayment(payment) {
        const db = this.getDB();
        payment.id = this.generateId('payment');
        payment.timestamp = new Date().toISOString();
        db.payments.push(payment);
        this.saveDB(db);
        return payment;
    }

    getUserPayments(userId) {
        return this.getDB().payments.filter(p => p.userId === userId);
    }

    // Helper Functions
    generateId(prefix) {
        return `${prefix}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }

    // Statistics
    getStatistics() {
        const db = this.getDB();
        return {
            totalSubjects: db.subjects.length,
            totalCourses: db.courses.length,
            totalQuestions: db.questions.length,
            totalAssignments: db.assignments.length,
            totalUsers: db.users.length,
            activeSubscriptions: db.subscriptions.filter(s => s.active).length,
            totalRevenue: db.payments.reduce((sum, p) => sum + p.amount, 0)
        };
    }

    // Search Functions
    searchCourses(query) {
        const db = this.getDB();
        const lowerQuery = query.toLowerCase();
        return db.courses.filter(c => 
            c.name.toLowerCase().includes(lowerQuery) ||
            c.description.toLowerCase().includes(lowerQuery)
        );
    }

    searchQuestions(query) {
        const db = this.getDB();
        const lowerQuery = query.toLowerCase();
        return db.questions.filter(q => 
            q.text.toLowerCase().includes(lowerQuery)
        );
    }

    // User Assignment Operations
    addUserAssignment(assignment) {
        const db = this.getDB();
        if (!db.userAssignments) {
            db.userAssignments = [];
        }
        assignment.id = this.generateId('userassign');
        assignment.createdAt = new Date().toISOString();
        assignment.status = 'pending'; // pending, started, completed
        db.userAssignments.push(assignment);
        this.saveDB(db);
        return assignment;
    }

    getUserAssignments(userId) {
        const db = this.getDB();
        if (!db.userAssignments) return [];
        return db.userAssignments.filter(a => a.userId === userId);
    }

    getAssignmentsByAssignmentId(assignmentId) {
        const db = this.getDB();
        if (!db.userAssignments) return [];
        return db.userAssignments.filter(a => a.assignmentId === assignmentId);
    }

    updateUserAssignment(id, updates) {
        const db = this.getDB();
        if (!db.userAssignments) return null;
        const assignment = db.userAssignments.find(a => a.id === id);
        if (assignment) {
            Object.assign(assignment, updates);
            this.saveDB(db);
            return assignment;
        }
        return null;
    }

    deleteUserAssignment(id) {
        const db = this.getDB();
        if (!db.userAssignments) return;
        db.userAssignments = db.userAssignments.filter(a => a.id !== id);
        this.saveDB(db);
    }

    getAllUserAssignments() {
        const db = this.getDB();
        if (!db.userAssignments) return [];
        return db.userAssignments;
    }

    // Mixed Questions Operations
    getMixedQuestionsBySubject(subjectId, count = 10) {
        const db = this.getDB();
        const subjectQuestions = db.questions.filter(q => q.subjectId === subjectId);
        
        // Shuffle and return requested count
        const shuffled = subjectQuestions.sort(() => Math.random() - 0.5);
        return shuffled.slice(0, Math.min(count, shuffled.length));
    }

    getMixedQuestionsByComplexity(subjectId, complexity, count = 10) {
        const db = this.getDB();
        const filteredQuestions = db.questions.filter(q => 
            q.subjectId === subjectId && q.complexity === complexity
        );
        
        const shuffled = filteredQuestions.sort(() => Math.random() - 0.5);
        return shuffled.slice(0, Math.min(count, shuffled.length));
    }

    getMixedQuestionsByComplexityDistribution(subjectId, totalCount = 10) {
        const db = this.getDB();
        const easyCount = Math.ceil(totalCount * 0.3);
        const mediumCount = Math.ceil(totalCount * 0.4);
        const hardCount = Math.ceil(totalCount * 0.3);
        
        const easy = this.getMixedQuestionsByComplexity(subjectId, 'Easy', easyCount);
        const medium = this.getMixedQuestionsByComplexity(subjectId, 'Medium', mediumCount);
        const hard = this.getMixedQuestionsByComplexity(subjectId, 'Hard', hardCount);
        
        return [...easy, ...medium, ...hard];
    }

    // Clear all data (for testing)
    clearAll() {
        localStorage.removeItem(this.dbName);
        this.initializeDB();
    }

    // Export data
    exportData() {
        return this.getDB();
    }

    // Import data
    importData(data) {
        localStorage.setItem(this.dbName, JSON.stringify(data));
    }
}

// Initialize database
const db = new Database();
