// Authentication Module

class Auth {
    constructor() {
        this.currentUser = this.loadCurrentUser();
    }

    register(email, password, name) {
        const existingUser = db.getUserByEmail(email);
        if (existingUser) {
            return { success: false, message: 'User already exists' };
        }

        const hashedPassword = this.hashPassword(password);
        const user = db.addUser({
            email,
            password: hashedPassword,
            name,
            role: 'user', // 'user' or 'admin'
            active: true,
            profileCompleted: false
        });

        this.currentUser = user;
        this.saveCurrentUser(user);
        return { success: true, user };
    }

    login(email, password) {
        const user = db.getUserByEmail(email);
        if (!user) {
            return { success: false, message: 'User not found' };
        }

        if (!this.verifyPassword(password, user.password)) {
            return { success: false, message: 'Invalid password' };
        }

        if (!user.active) {
            return { success: false, message: 'Account is inactive' };
        }

        this.currentUser = user;
        this.saveCurrentUser(user);
        return { success: true, user };
    }

    logout() {
        this.currentUser = null;
        localStorage.removeItem('currentUser');
    }

    getCurrentUser() {
        return this.currentUser;
    }

    isLoggedIn() {
        return this.currentUser !== null;
    }

    isAdmin() {
        return this.currentUser && this.currentUser.role === 'admin';
    }

    saveCurrentUser(user) {
        localStorage.setItem('currentUser', JSON.stringify(user));
    }

    loadCurrentUser() {
        const user = localStorage.getItem('currentUser');
        return user ? JSON.parse(user) : null;
    }

    updateProfile(userId, updates) {
        const user = db.updateUser(userId, updates);
        if (user) {
            this.currentUser = user;
            this.saveCurrentUser(user);
        }
        return user;
    }

    // Simple password hashing (for demo - use bcrypt in production)
    hashPassword(password) {
        return btoa(password); // Base64 encoding for demo purposes
    }

    verifyPassword(password, hash) {
        return btoa(password) === hash;
    }

    // Create a demo admin account
    createDemoAccounts() {
        const adminExists = db.getUserByEmail('admin@examhub.com');
        if (!adminExists) {
            db.addUser({
                email: 'admin@examhub.com',
                password: this.hashPassword('admin123'),
                name: 'Administrator',
                role: 'admin',
                active: true,
                profileCompleted: true
            });
        }

        const userExists = db.getUserByEmail('user@examhub.com');
        if (!userExists) {
            db.addUser({
                email: 'user@examhub.com',
                password: this.hashPassword('user123'),
                name: 'Test User',
                role: 'user',
                active: true,
                profileCompleted: true
            });
        }
    }
}

// Initialize authentication
const auth = new Auth();

// Create demo accounts on first load
auth.createDemoAccounts();

// Show login/register if not logged in
function showAuthModal() {
    const modal = document.createElement('div');
    modal.className = 'auth-modal';
    modal.innerHTML = `
        <div class="auth-container">
            <div class="auth-tabs">
                <button class="auth-tab active" onclick="switchAuthTab('login')">Login</button>
                <button class="auth-tab" onclick="switchAuthTab('register')">Register</button>
            </div>
            
            <div id="login-form" class="auth-form active">
                <h3>Login to ExamHub</h3>
                <input type="email" id="login-email" placeholder="Email" value="user@examhub.com">
                <input type="password" id="login-password" placeholder="Password" value="user123">
                <button onclick="performLogin()" class="btn btn-primary">Login</button>
                <p class="demo-hint">Demo: admin@examhub.com / admin123</p>
            </div>
            
            <div id="register-form" class="auth-form">
                <h3>Create New Account</h3>
                <input type="text" id="register-name" placeholder="Full Name">
                <input type="email" id="register-email" placeholder="Email">
                <input type="password" id="register-password" placeholder="Password">
                <input type="password" id="register-confirm" placeholder="Confirm Password">
                <button onclick="performRegister()" class="btn btn-primary">Register</button>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
}

function switchAuthTab(tab) {
    document.querySelectorAll('.auth-form').forEach(f => f.classList.remove('active'));
    document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
    
    document.getElementById(`${tab}-form`).classList.add('active');
    event.target.classList.add('active');
}

function performLogin() {
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    
    if (!email || !password) {
        alert('Please enter email and password');
        return;
    }
    
    const result = auth.login(email, password);
    if (result.success) {
        document.querySelector('.auth-modal').remove();
        initializeApp();
    } else {
        alert(result.message);
    }
}

function performRegister() {
    const name = document.getElementById('register-name').value;
    const email = document.getElementById('register-email').value;
    const password = document.getElementById('register-password').value;
    const confirm = document.getElementById('register-confirm').value;
    
    if (!name || !email || !password || !confirm) {
        alert('Please fill all fields');
        return;
    }
    
    if (password !== confirm) {
        alert('Passwords do not match');
        return;
    }
    
    const result = auth.register(email, password, name);
    if (result.success) {
        alert('Registration successful! Please login.');
        switchAuthTab('login');
        document.getElementById('login-email').value = email;
    } else {
        alert(result.message);
    }
}

function logout() {
    if (confirm('Are you sure you want to logout?')) {
        auth.logout();
        location.reload();
    }
}
