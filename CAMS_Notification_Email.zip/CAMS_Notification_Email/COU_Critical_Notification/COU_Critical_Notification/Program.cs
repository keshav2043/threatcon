﻿using System;
using ClosedXML.Excel;
using Dapper;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net.Mail;
namespace COU_Critical_Notification
{
	class Program
	{
		private static string connectionstring = "Server=10.129.160.186;Database=Live_MegaEOffice;User Id=sa;password=software;Trusted_Connection=False;MultipleActiveResultSets=true;Timeout=3600;";
        public class AccountBranchInfo
        {
            public string BranchCode { get; set; }
            public string BranchName { get; set; }
            public int ProvinceNo { get; set; }
            public int TotalPendings { get; set; }
            public string BM_Email { get; set; }
            public string OI_Email { get; set; }
            public string BR_Email { get; set; }
            public string PM_Email { get; set; }
        }
        static void Main(string[] args)
		{
			var PendingToUploadInfos = GetPendingtoUploadCriticalBranches().AsList();
			if (PendingToUploadInfos.Count > 0 && PendingToUploadInfos != null)
			{
                SendPendingToUploadBranchList(PendingToUploadInfos);
			}
		}

        public static IEnumerable<AccountBranchInfo> GetPendingtoUploadCriticalBranches()
        {

            SqlCommand cmd = new SqlCommand();

            List<AccountBranchInfo> PendingToUpload = new List<AccountBranchInfo>();
            try
            {

                using (SqlConnection con = new SqlConnection(connectionstring))
                {

                    PendingToUpload = SqlMapper.Query<AccountBranchInfo>(con, "[Cams].[mgGetTotalPendingToUploadCriticalAutoMail]", commandType: System.Data.CommandType.StoredProcedure).AsList();
                }

            }
            catch (Exception err)
            {
            }
            return PendingToUpload;
        }
        public static void SendPendingToUploadBranchList(List<AccountBranchInfo> branchInfos)
        { 
           List<int> Provinces = branchInfos.Select(s => s.ProvinceNo).Distinct().ToList();
            foreach (int p in Provinces)
            {
                List<AccountBranchInfo> branchPendingInfos = branchInfos.Where(x => x.ProvinceNo == p).ToList();
                SendPendingCriticalBranchInfo(branchPendingInfos);
            }
        }

        public static void SendPendingCriticalBranchInfo(List<AccountBranchInfo> ProvinceBranchInfos)
        {
            string ToEmail = string.Empty;
            string CCEmail = string.Empty;
            string DataTableBody = string.Empty;
            int SN = 0;
            string PM_Email = ProvinceBranchInfos.Select(x=>x.PM_Email).FirstOrDefault();
            CCEmail = "rajesh.sharma@nimb.com.np,sanjit@nimb.com.np,cou@nimb.com.np,it@nimb.com.np";

           
            if (!string.IsNullOrEmpty(PM_Email))
            {
                CCEmail += "," + PM_Email;
            }
            foreach (AccountBranchInfo branchInfo in ProvinceBranchInfos)
            {
                SN++;
                if (!string.IsNullOrEmpty(branchInfo.BM_Email))
                {
                    if (ToEmail.Length <= 0)
                    {
                        ToEmail = branchInfo.BM_Email;
                    }
                    else
                    {
                        ToEmail += ","+branchInfo.BM_Email;
                    }
                }

                if (!string.IsNullOrEmpty(branchInfo.OI_Email))
                {
                    if (ToEmail.Length <= 0)
                    {
                        ToEmail = branchInfo.OI_Email;
                    }
                    else
                    {
                        ToEmail += "," + branchInfo.OI_Email;
                    }
                }
                if (!string.IsNullOrEmpty(branchInfo.BR_Email))
                {
                    if (ToEmail.Length <= 0)
                    {
                        ToEmail = branchInfo.BR_Email;
                    }
                    else
                    {
                        ToEmail += "," + branchInfo.BR_Email;
                    }
                }
                DataTableBody += "<tr>";
                DataTableBody += "<td style='padding: 10px; font-size: 14px; color: #333;'>"+SN+"</td><td style='padding: 10px; font-size: 14px; color: #333;'>"+branchInfo.BranchCode+"</td><td style='padding: 10px; font-size: 14px; color: #333;'>"+branchInfo.BranchName+"</td><td style='padding: 10px; font-size: 14px; color: #333;'>"+branchInfo.ProvinceNo+"</td> <td style='padding: 10px; font-size: 14px; color: #333;'>"+branchInfo.TotalPendings+"</td>";
                DataTableBody += "</tr>";
            }
            string body = "";
            string TempleteName = "CriticalPendingToUpload.html";
            string TempletePath = System.IO.Directory.GetCurrentDirectory();
            var TempleteBasePath = AppContext.BaseDirectory.Substring(0, AppContext.BaseDirectory.IndexOf("bin"));
            var TempleteFilePath = Path.Combine(TempleteBasePath, TempleteName);
            using (StreamReader reader = new StreamReader(Path.Combine(TempleteFilePath)))
            {
                body = reader.ReadToEnd();
            }
            body = body.Replace("{DataTable}", DataTableBody.ToString());
            SendMail(ToEmail, CCEmail, "", "CAMS:Pending Uploads Have Exceeded Control", body, null);
        }
        public static void SendMail(string receiver, string ccEmail, string bccEmail, string subject, string body, string Attachment)
        {
            string Host = "10.1.2.7";
            int MailPort = 25;
            bool EnableSsl = false;

            MailMessage m = new MailMessage();
            SmtpClient sc = new SmtpClient();
            m.From = new MailAddress("eoffice@nimb.com.np", "NIMB E-Office");
            m.Subject = subject;
            m.Body = body;
            m.IsBodyHtml = true;

            if (!string.IsNullOrEmpty(Attachment))
            {
                m.Attachments.Add(new System.Net.Mail.Attachment(Attachment));
            }

            if (!string.IsNullOrEmpty(receiver))
            {
                if (receiver.Contains(","))
                {
                    string[] ToId = receiver.Split(',');
                    foreach (string toEmail in ToId)
                    {
                        m.To.Add(new MailAddress(toEmail)); //Adding Multiple CC email Id
                    }
                }
                else
                {
                    m.To.Add(new MailAddress(receiver));
                }

            }
            if (!string.IsNullOrEmpty(ccEmail))
            {
                if (ccEmail.Contains(","))
                {
                    string[] CCId = ccEmail.Split(',');
                    foreach (string CCEmail in CCId)
                    {
                        m.CC.Add(new MailAddress(CCEmail)); //Adding Multiple CC email Id
                    }
                }
                else
                {
                    m.CC.Add(new MailAddress(ccEmail));
                }

            }
            if (!string.IsNullOrEmpty(bccEmail))
            {
                if (bccEmail.Contains(","))
                {
                    string[] BCId = ccEmail.Split(',');
                    foreach (string BCEmail in BCId)
                    {
                        m.CC.Add(new MailAddress(BCEmail)); //Adding Multiple CC email Id
                    }
                }
                else
                {
                    m.CC.Add(new MailAddress(bccEmail));
                }

            }
            sc.Host = Host;
            try
            {
                sc.Port = MailPort;
                sc.UseDefaultCredentials = false;

                sc.EnableSsl = EnableSsl;

                sc.Send(m);
            }
            catch (Exception ex)
            {
                string msg = ex.Message;
                if (ex.InnerException != null)
                {

                    msg = ex.InnerException.Message;
                }

            }
        }


        
    }
}
