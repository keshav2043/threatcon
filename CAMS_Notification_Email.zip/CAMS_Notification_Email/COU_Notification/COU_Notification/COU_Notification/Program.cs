﻿using ClosedXML.Excel;
using Dapper;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net.Mail;

namespace COU_Notification
{
	class Program
	{
		private static string connectionstring = "Server=10.129.160.186;Database=Live_MegaEOffice;User Id=sa;password=software;Trusted_Connection=False;MultipleActiveResultSets=true;Timeout=3600;";
		static void Main(string[] args)
		{

            var accountInfos = getPendingtoValidateAccountList().AsList();
            var PendingToUploadInfos = getPendingtoUploadAccountList().AsList();
            var PendingToForwardInfos = getPendingtoForwardToCOUAccountList().AsList();
            var RejectedAccountInfos = getRejectedAccountInfoList().AsList();
            if (accountInfos.Count > 0 && accountInfos != null)
            {
				SendPendingToValidateMail(accountInfos);
			}
            if (PendingToUploadInfos.Count > 0 && PendingToUploadInfos != null)
            {
				SendPendingToUploadList(PendingToUploadInfos);
			}
            if (PendingToForwardInfos.Count > 0 && PendingToForwardInfos != null)
            {
				SendPendingToForwardList(PendingToForwardInfos);
			}
            if (RejectedAccountInfos.Count > 0 && RejectedAccountInfos != null)
            {
                SendRejectedByCOUAccountList(RejectedAccountInfos);
            }
        }
        public class AccountInfos
        {
            public int AccountInfoId { get; set; }
            public string BranchCode { get; set; }
            public string BranchName { get; set; }
            public string ReferenceNo { get; set; }
            public string ProgressStatus { get; set; }

            public string AccountNumber { get; set; }
            public string CustomerNo { get; set; }
            public string CustomerName { get; set; }
            public string Initiator { get; set; }
            public DateTime PendingSinceDate { get; set; }
            public int PendingSinceDays { get; set; }
            public int ProvinceId { get; set; }
            public string ProductCode { get; set; }
            public string DRStatus { get; set; }
            public string RejectedBy { get; set; }
            public string Comment { get; set; }
        }
        public class PendingAccountInfos
        { 
            public int SN { get; set; }
            public int PendingToUploadTotalId { get; set; }
            public string BranchCode { get; set; }
            public string BranchName { get; set; }
            public string GroupName { get; set; }
            public string AccountName { get; set; }
            public string AccountNumber { get; set; }
            public string CustomerNo { get; set; }
            public DateTime AccountOpenDate { get; set; }
            public int PendingDays { get; set; }
            public string ProductCode { get; set; }
            public int ProvinceId { get; set; }

        }
        public class TotalAccountInfo
        {
            public int Total { get; set; }
            public string BranchCode { get;set;}
           public string BranchName { get;set;}
          public int Province { get; set; }
}
        public static IEnumerable<AccountInfos> getPendingtoValidateAccountList()
        {

            SqlCommand cmd = new SqlCommand();

            List<AccountInfos> PendingToValidate = new List<AccountInfos>();
            try
            {

                using (SqlConnection con = new SqlConnection(connectionstring))
                {

                    PendingToValidate = SqlMapper.Query<AccountInfos>(con, "[Cams].[mgGetPendingtoValidateAccountList]", commandType: System.Data.CommandType.StoredProcedure).AsList();
                }

            }
            catch (Exception err)
            {
            }
            return PendingToValidate;
        }
        private static void SendPendingToValidateMail(List<AccountInfos> accountInfos)
        {
            string fileName = string.Empty;
            int TotalPending = accountInfos.Count;
            int NewPending = accountInfos.Where(x => x.ProgressStatus == "U").ToList().Count;
            int ReValidatePending = accountInfos.Where(x => x.ProgressStatus == "O").ToList().Count;
            fileName = "COUPendingToValidateReport.html";
            string path = System.IO.Directory.GetCurrentDirectory();
            var basepath = AppContext.BaseDirectory.Substring(0, AppContext.BaseDirectory.IndexOf("bin"));
            var filepath = Path.Combine(basepath, fileName);
            string body = string.Empty;
            string TableRows = string.Empty;

            foreach (AccountInfos af in accountInfos)
            {
                string pendingType = (af.ProgressStatus == "U" ? "Untouch By COU" : "Re-Validate");
                string Branch = string.Empty;
                TableRows += "<tr>";
                Branch = af.BranchCode + " - " + af.BranchName;
                TableRows += "<td>" + Branch + "</td>";
                TableRows += "<td>" + af.ReferenceNo + "</td>";
                TableRows += "<td>" + af.AccountNumber + "</td>";
                TableRows += "<td>" + af.CustomerName + "</td>";
                TableRows += "<td>" + af.Initiator + "</td>";
                TableRows += "<td>" + af.PendingSinceDate.ToShortDateString() + " - " + af.PendingSinceDate.ToString("hh:mm tt") + "</td>";
                TableRows += "<td>" + af.PendingSinceDays + "</td>";
                TableRows +="<td>"+ pendingType + "</td>";
                TableRows += "<tr>";
            }

            try
            {
                using (StreamReader reader = new StreamReader(Path.Combine(filepath)))
                {
                    body = reader.ReadToEnd();
                }

                body = body.Replace("{total}", TotalPending.ToString());
                body = body.Replace("{totalnewaccount}", NewPending.ToString());
                body = body.Replace("{totalrevalidate}", ReValidatePending.ToString());
                body = body.Replace("{tablerow}", TableRows);

				string ToMail = "rajesh.sharma@nimb.com.np";
				string CCMAIL = "sanjit@nimb.com.np,cou@nimb.com.np,it@nimb.com.np";

				//string ToMail = "raju.pandey@nimb.com.np";
				//string CCMAIL = "raju.pandey@nimb.com.np";

				SendMail(ToMail, CCMAIL, "", "CAMS:Pending To Validate Accounts By COU", body,null);
            }
            catch (Exception err)
            {
                //return body;
            }
        }
        public static void SendMail(string receiver, string ccEmail, string bccEmail, string subject, string body,string Attachment)
        {
            string Host = "10.1.2.7";
            int MailPort = 25;
            bool EnableSsl = false;

            MailMessage m = new MailMessage();
            SmtpClient sc = new SmtpClient();
            m.From = new MailAddress("eoffice@nimb.com.np", "NIMB E-Office");
            m.Subject = subject;
            m.Body = body;
            m.IsBodyHtml = true;

            if (!string.IsNullOrEmpty(Attachment))
            {
                m.Attachments.Add(new System.Net.Mail.Attachment(Attachment));
            }

            if (!string.IsNullOrEmpty(receiver))
            {
                if (receiver.Contains(","))
                {
                    string[] ToId = receiver.Split(',');
                    foreach (string toEmail in ToId)
                    {
                        m.To.Add(new MailAddress(toEmail)); //Adding Multiple CC email Id
                    }
                }
                else
                {
                    m.To.Add(new MailAddress(receiver));
                }

            }
            if (!string.IsNullOrEmpty(ccEmail))
            {
                if (ccEmail.Contains(","))
                {
                    string[] CCId = ccEmail.Split(',');
                    foreach (string CCEmail in CCId)
                    {
                        m.CC.Add(new MailAddress(CCEmail)); //Adding Multiple CC email Id
                    }
                }
                else
                {
                    m.CC.Add(new MailAddress(ccEmail));
                }

            }
            if (!string.IsNullOrEmpty(bccEmail))
            {
                if (bccEmail.Contains(","))
                {
                    string[] BCId = ccEmail.Split(',');
                    foreach (string BCEmail in BCId)
                    {
                        m.CC.Add(new MailAddress(BCEmail)); //Adding Multiple CC email Id
                    }
                }
                else
                {
                    m.CC.Add(new MailAddress(bccEmail));
                }

            }
            sc.Host = Host;
            try
            {
                sc.Port = MailPort;
                sc.UseDefaultCredentials = false;

                sc.EnableSsl = EnableSsl;

                sc.Send(m);
            }
            catch (Exception ex)
            {
                string msg = ex.Message;
                if (ex.InnerException != null)
                {

                    msg = ex.InnerException.Message;
                }

            }
        }
        public static IEnumerable<PendingAccountInfos> getPendingtoUploadAccountList()
        {

            SqlCommand cmd = new SqlCommand();

            List<PendingAccountInfos> PendingToUpload = new List<PendingAccountInfos>();
            try
            {

                using (SqlConnection con = new SqlConnection(connectionstring))
                {

                    PendingToUpload = SqlMapper.Query<PendingAccountInfos>(con, "[Cams].[mgGetPendingToUploadAutoMail]", commandType: System.Data.CommandType.StoredProcedure).AsList();
                }

            }
            catch (Exception err)
            {
            }
            return PendingToUpload;
        }
        public static IEnumerable<TotalAccountInfo> getTotalPendingtoUploadAccounts()
        {

            SqlCommand cmd = new SqlCommand();

            List<TotalAccountInfo> TotalPendingToUpload = new List<TotalAccountInfo>();
            try
            {

                using (SqlConnection con = new SqlConnection(connectionstring))
                {

                    TotalPendingToUpload = SqlMapper.Query<TotalAccountInfo>(con, "[Cams].[mgGetTotalPendingToUploadAutoMail]", commandType: System.Data.CommandType.StoredProcedure).AsList();
                }

            }
            catch (Exception err)
            {
            }
            return TotalPendingToUpload;
        }
        public static void SendPendingToUploadList(List<PendingAccountInfos> pendingAccounts)
		{
            int TotalPending = pendingAccounts.Count;
            List<TotalAccountInfo> TotalPendings = getTotalPendingtoUploadAccounts().ToList();
            string contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            string fileName = string.Empty;
            try
            {
                fileName = "AccountPendingToUpload.xlsx";
                string path = System.IO.Directory.GetCurrentDirectory();
                var basepath = AppContext.BaseDirectory.Substring(0, AppContext.BaseDirectory.IndexOf("bin"));
                var filepath = Path.Combine(basepath, fileName);
                if (File.Exists(@filepath))
                {
                    File.Delete(@filepath);
                }
                int CountPending = 0;
                using (var workbook = new XLWorkbook())
                {

                    IXLWorksheet worksheet = workbook.Worksheets.Add("Pending Upload Report");
                    IXLWorksheet worksheetTotal = workbook.Worksheets.Add("Total Pending");

                    worksheet.Cell(1, 1).Value = "SN";
                    worksheet.Cell(1, 2).Value = "Branch Name";
                    worksheet.Cell(1, 3).Value = "Branch Code";
                    worksheet.Cell(1, 4).Value = "CPU Fold";
                    worksheet.Cell(1, 5).Value = "Account Name";
                    worksheet.Cell(1, 6).Value = "Account Number";
                    worksheet.Cell(1, 7).Value = "Customer No";
                    worksheet.Cell(1, 8).Value = "Account Open Date";
                    worksheet.Cell(1, 9).Value = "Pending Days";
                    worksheet.Cell(1, 10).Value = "Product Code";
                    worksheet.Cell(1, 11).Value = "Province";
                    worksheet.Row(1).Style.Font.SetBold();

                    worksheetTotal.Cell(1, 1).Value = "SN";
                    worksheetTotal.Cell(1, 2).Value = "Branch Name";
                    worksheetTotal.Cell(1, 3).Value = "Branch Code";
                    worksheetTotal.Cell(1, 4).Value = "Toal Pending";
                    worksheetTotal.Cell(1, 5).Value = "Province";
                    worksheetTotal.Row(1).Style.Font.SetBold();

                    int Index = 0;
                    int Indext = 0;
                    foreach (PendingAccountInfos s in pendingAccounts)
                    {
                        CountPending++;
                        Index = Index + 1;
                        worksheet.Cell(Index + 1, 1).Value = CountPending;
                        worksheet.Cell(Index + 1, 2).Value = s.BranchName;
                        //worksheet.Cell(Index + 1, 3).SetValue<string>(s.BranchCode);
                        worksheet.Cell(Index + 1, 3).Value=s.BranchCode;
                        worksheet.Cell(Index + 1, 4).Value = s.GroupName;
                        worksheet.Cell(Index + 1, 5).Value = s.AccountName;
                        worksheet.Cell(Index + 1, 6).Value = s.AccountNumber;
                        worksheet.Cell(Index + 1, 7).Value = s.CustomerNo;
                        //worksheet.Cell(Index + 1, 6).SetValue<string>(s.AccountNumber);
                        //worksheet.Cell(Index + 1, 7).SetValue<string>(s.CustomerNo);
                        worksheet.Cell(Index + 1, 8).Value = String.Format("{0:MM-dd-yyyy}", s.AccountOpenDate);
                        worksheet.Cell(Index + 1, 9).Value = s.PendingDays;
                        worksheet.Cell(Index + 1, 10).Value = s.ProductCode;
                        worksheet.Cell(Index + 1, 11).Value = s.ProvinceId;
                    }
                    foreach (TotalAccountInfo t in TotalPendings)
                    {
                        Indext = Indext + 1;
                        worksheetTotal.Cell(Indext + 1, 1).Value = Indext;
                        worksheetTotal.Cell(Indext + 1, 2).Value = t.BranchName;
                        worksheetTotal.Cell(Indext + 1, 3).Value= t.BranchCode;
                        //worksheetTotal.Cell(Indext + 1, 3).SetValue<string>(t.BranchCode);
                        worksheetTotal.Cell(Indext + 1, 4).Value = t.Total;
                        worksheetTotal.Cell(Indext + 1, 5).Value = t.Province;

                    }
                    worksheet.Columns().AdjustToContents();
                    worksheetTotal.Columns().AdjustToContents();
                    using (var stream = new MemoryStream())
                    {

                        workbook.SaveAs(stream);
                        workbook.SaveAs(filepath);
                        //var content = stream.ToArray();
                        
                        //return File(content, contentType, fileName);
                    }
                    SendPendingToUploadMail(filepath, TotalPending);
                }
            }
            catch (Exception ex)
            {
                string msgEror = ex.Message;
                if (ex.InnerException != null)
                {
                    msgEror = ex.InnerException.Message;
                }
            }
        }
        public static void SendPendingToUploadMail(string FilePath,int TotalPending)
        {
            if (File.Exists(@FilePath))
            {
                string ToMail = "rajesh.sharma@nimb.com.np";
                string CCMAIL = "sanjit@nimb.com.np,cou@nimb.com.np,branchmanagers@nimb.com.np,branch_operation_incharge@nimb.com.np,branch_operations@nimb.com.np,province_managers@nimb.com.np,csd_all@nimb.com.np,it@nimb.com.np";
                string body = "";
                string TempleteName = "PendingToUploadReport.html";
                string TempletePath = System.IO.Directory.GetCurrentDirectory();
                var TempleteBasePath = AppContext.BaseDirectory.Substring(0, AppContext.BaseDirectory.IndexOf("bin"));
                var TempleteFilePath = Path.Combine(TempleteBasePath, TempleteName);
                using (StreamReader reader = new StreamReader(Path.Combine(TempleteFilePath)))
                {
                    body = reader.ReadToEnd();
                }
                body = body.Replace("{total}", TotalPending.ToString());
                SendMail(ToMail, CCMAIL, "", "CAMS:Pending To Upload Accounts", body,FilePath);
            }
        }
        public static IEnumerable<AccountInfos> getPendingtoForwardToCOUAccountList()
        {

            SqlCommand cmd = new SqlCommand();

            List<AccountInfos> PendingToForward = new List<AccountInfos>();
            try
            {
                using (SqlConnection con = new SqlConnection(connectionstring))
                {
                    PendingToForward = SqlMapper.Query<AccountInfos>(con, "[Cams].[mgGetPendingToForwardAutoMail]", commandType: System.Data.CommandType.StoredProcedure).AsList();
                }
            }
            catch (Exception err)
            {

            }
            return PendingToForward;
        }
        public static void SendPendingToForwardList(List<AccountInfos> accountInfos)
        {
            int TotalPending = accountInfos.Count;
            string fileName = string.Empty;
            try
            {
                fileName = "AccountsPendingToForwardToCOU.xlsx";
                string path = System.IO.Directory.GetCurrentDirectory();
                var basepath = AppContext.BaseDirectory.Substring(0, AppContext.BaseDirectory.IndexOf("bin"));
                var filepath = Path.Combine(basepath, fileName);
                if (File.Exists(@filepath))
                {
                    File.Delete(@filepath);
                }
                int CountPending = 0;
                using (var workbook = new XLWorkbook())
                {

                    IXLWorksheet worksheet = workbook.Worksheets.Add("Pending Forward Report");

                    worksheet.Cell(1, 1).Value = "SN";
                    worksheet.Cell(1, 2).Value = "Reference No";
                    worksheet.Cell(1, 3).Value = "Branch Name";
                    worksheet.Cell(1, 4).Value = "Branch Code";
                    worksheet.Cell(1, 5).Value = "Account Name";
                    worksheet.Cell(1, 6).Value = "Account Number";
                    worksheet.Cell(1, 7).Value = "Customer No";
                    worksheet.Cell(1, 8).Value = "Product Code";
                    worksheet.Cell(1, 9).Value = "Province";
                    worksheet.Cell(1, 10).Value = "Pending Days";
                    worksheet.Row(1).Style.Font.SetBold();
                   

                    int Index = 0;
                    foreach (AccountInfos s in accountInfos)
                    {
                        CountPending++;
                        Index = Index + 1;
                        worksheet.Cell(Index + 1, 1).Value = CountPending;
                        worksheet.Cell(Index + 1, 2).Value = s.ReferenceNo;
                        worksheet.Cell(Index + 1, 3).Value = s.BranchName;
                        //worksheet.Cell(Index + 1, 3).SetValue<string>(s.BranchCode);
                        worksheet.Cell(Index + 1, 4).Value = s.BranchCode;
                        worksheet.Cell(Index + 1, 5).Value = s.CustomerName;
                        worksheet.Cell(Index + 1, 6).Value = s.AccountNumber;
                        worksheet.Cell(Index + 1, 7).Value = s.CustomerNo;
                        //worksheet.Cell(Index + 1, 6).SetValue<string>(s.AccountNumber);
                        //worksheet.Cell(Index + 1, 7).SetValue<string>(s.CustomerNo);
                        worksheet.Cell(Index + 1, 8).Value = s.ProductCode;
                        worksheet.Cell(Index + 1, 9).Value = s.ProvinceId;
                        worksheet.Cell(Index + 1, 10).Value = s.PendingSinceDays;
                    }
                    worksheet.Columns().AdjustToContents();
                    using (var stream = new MemoryStream())
                    {

                        workbook.SaveAs(stream);
                        workbook.SaveAs(filepath);
                        //var content = stream.ToArray();

                        //return File(content, contentType, fileName);
                    }
                    SendPendingToForwardMail(filepath, TotalPending);
                }
            }
            catch (Exception ex)
            {
                string msgEror = ex.Message;
                if (ex.InnerException != null)
                {
                    msgEror = ex.InnerException.Message;
                }
            }
        }
        public static void SendPendingToForwardMail(string FilePath, int TotalPending)
        {
            if (File.Exists(@FilePath))
            {
                string ToMail = "sanjit@nimb.com.np,cou@nimb.com.np";
                string CCMAIL = "rajesh.sharma@nimb.com.np,branchmanagers@nimb.com.np,branch_operation_incharge@nimb.com.np,branch_operations@nimb.com.np,province_managers@nimb.com.np,it@nimb.com.np";
                string body = "";
                string TempleteName = "PendingToForwardReport.html";
                string TempletePath = System.IO.Directory.GetCurrentDirectory();
                var TempleteBasePath = AppContext.BaseDirectory.Substring(0, AppContext.BaseDirectory.IndexOf("bin"));
                var TempleteFilePath = Path.Combine(TempleteBasePath, TempleteName);
                using (StreamReader reader = new StreamReader(Path.Combine(TempleteFilePath)))
                {
                    body = reader.ReadToEnd();
                }
                body = body.Replace("{total}", TotalPending.ToString());
                SendMail(ToMail, CCMAIL, "", "CAMS:Pending To Forward Accounts To Validate", body, FilePath);
            }
        }
        public static IEnumerable<AccountInfos> getRejectedAccountInfoList()
        {

            SqlCommand cmd = new SqlCommand();

            List<AccountInfos> rejectedAccountInfos = new List<AccountInfos>();
            try
            {
                using (SqlConnection con = new SqlConnection(connectionstring))
                {
                    rejectedAccountInfos = SqlMapper.Query<AccountInfos>(con, "[Cams].[mgGetRejectedAccountListAutoMail]", commandType: System.Data.CommandType.StoredProcedure).AsList();
                }
            }
            catch (Exception err)
            {

            }
            return rejectedAccountInfos;
        }
        public static void SendRejectedByCOUAccountList(List<AccountInfos> accountInfos)
        {
            int TotalPending = accountInfos.Count;
            string fileName = string.Empty;
            try
            {
                fileName = "RejectedByCOUAccounts.xlsx";
                string path = System.IO.Directory.GetCurrentDirectory();
                var basepath = AppContext.BaseDirectory.Substring(0, AppContext.BaseDirectory.IndexOf("bin"));
                var filepath = Path.Combine(basepath, fileName);
                if (File.Exists(@filepath))
                {
                    File.Delete(@filepath);
                }
                int CountPending = 0;
                using (var workbook = new XLWorkbook())
                {

                    IXLWorksheet worksheet = workbook.Worksheets.Add("Rejected By COU Report");

                    worksheet.Cell(1, 1).Value = "SN";
                    worksheet.Cell(1, 2).Value = "Reference No";
                    worksheet.Cell(1, 3).Value = "Branch Name";
                    worksheet.Cell(1, 4).Value = "Branch Code";
                    worksheet.Cell(1, 5).Value = "Account Name";
                    worksheet.Cell(1, 6).Value = "Account Number";
                    worksheet.Cell(1, 7).Value = "Customer No";
                    worksheet.Cell(1, 8).Value = "Product Code";
                    worksheet.Cell(1, 9).Value = "Province";
                    worksheet.Cell(1, 10).Value = "Rejected Day";
                    worksheet.Cell(1, 11).Value = "IsDR";
                    worksheet.Cell(1, 12).Value = "Rejected By";
                    worksheet.Cell(1, 13).Value = "Rejected Comment";
                    worksheet.Row(1).Style.Font.SetBold();


                    int Index = 0;
                    foreach (AccountInfos s in accountInfos)
                    {
                        CountPending++;
                        Index = Index + 1;
                        worksheet.Cell(Index + 1, 1).Value = CountPending;
                        worksheet.Cell(Index + 1, 2).Value = s.ReferenceNo;
                        worksheet.Cell(Index + 1, 3).Value = s.BranchName;
                        //worksheet.Cell(Index + 1, 3).SetValue<string>(s.BranchCode);
                        worksheet.Cell(Index + 1, 4).Value = s.BranchCode;
                        worksheet.Cell(Index + 1, 5).Value = s.CustomerName;
                        worksheet.Cell(Index + 1, 6).Value = s.AccountNumber;
                        worksheet.Cell(Index + 1, 7).Value = s.CustomerNo;
                        //worksheet.Cell(Index + 1, 6).SetValue<string>(s.AccountNumber);
                        //worksheet.Cell(Index + 1, 7).SetValue<string>(s.CustomerNo);
                        worksheet.Cell(Index + 1, 8).Value = s.ProductCode;
                        worksheet.Cell(Index + 1, 9).Value = s.ProvinceId;
                        worksheet.Cell(Index + 1, 10).Value = s.PendingSinceDays;

                        worksheet.Cell(Index + 1, 11).Value = (s.DRStatus=="Y"?"Yes":"No");
                        worksheet.Cell(Index + 1, 12).Value = s.RejectedBy;
                        worksheet.Cell(Index + 1, 13).Value = s.Comment;

                    }
                    worksheet.Columns().AdjustToContents();
                    using (var stream = new MemoryStream())
                    {

                        workbook.SaveAs(stream);
                        workbook.SaveAs(filepath);
                        //var content = stream.ToArray();

                        //return File(content, contentType, fileName);
                    }
                    SendRejectedByCOUAccountsMail(filepath, TotalPending);
                }
            }
            catch (Exception ex)
            {
                string msgEror = ex.Message;
                if (ex.InnerException != null)
                {
                    msgEror = ex.InnerException.Message;
                }
            }
        }
        public static void SendRejectedByCOUAccountsMail(string FilePath, int TotalPending)
        {
            if (File.Exists(@FilePath))
            {
				string ToMail = "rajesh.sharma@nimb.com.np";
				string CCMAIL = "sanjit@nimb.com.np,cou@nimb.com.np,branchmanagers@nimb.com.np,branch_operation_incharge@nimb.com.np,branch_operations@nimb.com.np,province_managers@nimb.com.np,it@nimb.com.np";
				//string ToMail = "raju.pandey@nimb.com.np";
				//string CCMAIL = "raju.pandey@nimb.com.np";
				string body = "";
                string TempleteName = "AccountsRejectedByCOU.html";
                string TempletePath = System.IO.Directory.GetCurrentDirectory();
                var TempleteBasePath = AppContext.BaseDirectory.Substring(0, AppContext.BaseDirectory.IndexOf("bin"));
                var TempleteFilePath = Path.Combine(TempleteBasePath, TempleteName);
                using (StreamReader reader = new StreamReader(Path.Combine(TempleteFilePath)))
                {
                    body = reader.ReadToEnd();
                }
                body = body.Replace("{total}", TotalPending.ToString());
                SendMail(ToMail, CCMAIL, "", "CAMS:Accounts Rejected By COU", body, FilePath);
            }
        }

    }
}
