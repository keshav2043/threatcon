import re
import json
from pathlib import Path
from typing import List, Dict, Any, Optional

import requests
from bs4 import BeautifulSoup

USER_AGENT = "Mozilla/5.0 (compatible; BankingProductComparer/1.0)"
DEFAULT_HEADERS = {"User-Agent": USER_AGENT}


def load_json(path: str) -> Dict[str, Any]:
    file_path = Path(path)
    if not file_path.exists():
        return {}
    with file_path.open("r", encoding="utf-8") as f:
        return json.load(f)


def load_banks(path: str = "bank_list.json") -> List[Dict[str, Any]]:
    data = load_json(path)
    return data.get("banks", [])


def load_product_profiles(path: str = "bank_profiles.json") -> List[Dict[str, Any]]:
    data = load_json(path)
    return data.get("banks", [])


def find_profile(bank_slug: str, product_type: str, profiles: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    for bank in profiles:
        if bank.get("slug") == bank_slug:
            return bank.get("products", {}).get(product_type)
    return None


def fetch_html(url: str, timeout: int = 10) -> Optional[str]:
    try:
        resp = requests.get(url, headers=DEFAULT_HEADERS, timeout=timeout)
        resp.raise_for_status()
        return resp.text
    except Exception:
        return None


def sanitize_text(html: str) -> str:
    soup = BeautifulSoup(html, "lxml")
    for tag in soup(["script", "style", "noscript"]):
        tag.extract()
    return soup.get_text(separator=" ", strip=True)


def extract_interest(text: str) -> Optional[float]:
    matches = re.findall(r"(\d+(?:\.\d+)?)\s*%", text)
    if not matches:
        return None
    values = [float(x) for x in matches]
    return max(values)


def extract_fees(text: str) -> Optional[float]:
    fee_keywords = ["fee", "fees", "charge", "charges", "processing"]
    for keyword in fee_keywords:
        pattern = rf"{keyword}[^\d\n\r]?(\d+[\.,]?\d*)"
        m = re.search(pattern, text, flags=re.I)
        if m:
            try:
                return float(m.group(1).replace(",", ""))
            except ValueError:
                continue
    amounts = re.findall(r"(\d+[\.,]?\d*)", text)
    if amounts:
        try:
            return float(amounts[0].replace(",", ""))
        except ValueError:
            return None
    return None


def extract_tenure(text: str) -> Optional[int]:
    m = re.search(r"(\d+)\s*(?:months|month|yrs|years|year)", text, flags=re.I)
    if m:
        return int(m.group(1))
    return None


def extract_min_balance(text: str) -> Optional[float]:
    m = re.search(r"(?:minimum|min)\s*(?:balance|deposit|amount)\s*(?:of|is|:)?\s*(\d+[\.,]?\d*)", text, flags=re.I)
    if m:
        try:
            return float(m.group(1).replace(",", ""))
        except ValueError:
            return None
    return None


def extract_benefits(html: str) -> List[str]:
    soup = BeautifulSoup(html, "lxml")
    bullets = [li.get_text(separator=" ", strip=True) for li in soup.find_all("li") if li.get_text(strip=True)]
    if bullets:
        return bullets[:10]
    text = sanitize_text(html)
    sentences = re.split(r"[\.\n]\s*", text)
    return [s.strip() for s in sentences if len(s.strip()) > 40][:8]


def parse_product_page(html: str, url: str) -> Dict[str, Any]:
    text = sanitize_text(html)
    return {
        "url": url,
        "success": True,
        "source": "scraped",
        "interest_rate": extract_interest(text),
        "fees": extract_fees(text),
        "tenure_months": extract_tenure(text),
        "min_balance": extract_min_balance(text),
        "benefits": extract_benefits(html),
    }


def merge_profile(result: Dict[str, Any], profile: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    merged = dict(result)
    if not profile:
        return merged
    for field in ["interest_rate", "fees", "min_balance", "tenure_months", "benefits", "notes", "annual_fee", "reward_rate"]:
        if merged.get(field) in (None, [], "") and profile.get(field) is not None:
            merged[field] = profile.get(field)
    if merged.get("source") != "scraped" and profile:
        merged["source"] = "profile"
    if result.get("source") == "scraped" and merged.get("source") == "scraped" and profile:
        merged["source"] = "scraped+profile"
    return merged


def scrape_all(product_type: str, bank_list_path: str = "bank_list.json", profile_path: str = "bank_profiles.json") -> List[Dict[str, Any]]:
    banks = load_banks(bank_list_path)
    profiles = load_product_profiles(profile_path)
    out: List[Dict[str, Any]] = []
    for bank in banks:
        slug = bank.get("slug")
        name = bank.get("name")
        products = bank.get("products", {})
        url = products.get(product_type)
        profile = find_profile(slug, product_type, profiles)
        result = {
            "bank": name,
            "slug": slug,
            "product_type": product_type,
            "url": url or (profile.get("url") if profile else None),
            "success": False,
            "source": "profile" if profile else "none",
            "interest_rate": None,
            "fees": None,
            "tenure_months": None,
            "min_balance": None,
            "benefits": [],
            "notes": None,
        }
        if url:
            html = fetch_html(url)
            if html:
                scraped = parse_product_page(html, url)
                result.update(scraped)
        if profile:
            result = merge_profile(result, profile)
        if result.get("interest_rate") is not None or result.get("fees") is not None or result.get("benefits"):
            result["success"] = True
        else:
            result["success"] = False
            result["error"] = "No reliable data found"
        out.append(result)
    return out
