from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pathlib import Path
from pydantic import BaseModel
from typing import Dict, Any, Optional

import scraper
import comparator

app = FastAPI(title="Banking Product Comparison")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

STATIC_DIR = Path(__file__).parent / "public"
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


@app.get("/")
def root():
    index_path = STATIC_DIR / "index.html"
    if index_path.exists():
        return FileResponse(index_path)
    raise HTTPException(status_code=404, detail="index.html not found in public directory")


class CompareRequest(BaseModel):
    product_type: str
    amount: Optional[float] = None
    tenure_months: Optional[int] = None
    preferences: Dict[str, float] = {}


@app.get("/banks")
def get_banks() -> Dict[str, Any]:
    banks = scraper.load_banks("bank_list.json")
    return {
        "banks": [
            {
                "name": b.get("name"),
                "slug": b.get("slug"),
                "products": list(b.get("products", {}).keys()),
                "urls": b.get("products", {}),
            }
            for b in banks
        ]
    }


@app.post("/compare")
def compare(req: CompareRequest) -> Dict[str, Any]:
    product = req.product_type
    if product not in {"savings", "fd", "loan", "credit_card"}:
        raise HTTPException(status_code=400, detail="product_type must be savings, fd, loan, or credit_card")

    prefs = req.preferences or {}
    items = scraper.scrape_all(product, "bank_list.json", "bank_profiles.json")
    if not items:
        raise HTTPException(status_code=404, detail=f"No product pages found for product '{product}'. Please configure bank_list.json with product URLs.")

    ranked = comparator.rank_products(items, product, prefs, amount=req.amount, tenure_months=req.tenure_months, top_k=6)
    return {
        "product": product,
        "request": {
            "amount": req.amount,
            "tenure_months": req.tenure_months,
            "preferences": prefs,
        },
        "results": ranked,
    }


@app.get("/products")
def get_products() -> Dict[str, Any]:
    return {"products": ["savings", "fd", "loan", "credit_card"]}
