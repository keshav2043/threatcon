# Banking Product Comparison

Comprehensive FastAPI app that compares savings, fixed deposit, loan, and credit card offers using live page scraping plus local bank profile data. Update `bank_list.json` and `bank_profiles.json` for the latest Nepali bank products before running.

Quick start

1. Create a virtualenv and install dependencies:

```bash
python -m venv .venv
source .venv/bin/activate  # or `.venv\\Scripts\\activate` on Windows
pip install -r "requirements.txt"
```

2. Run the app:

```bash
uvicorn main:app --reload --host 127.0.0.1 --port 8000
```

3. Open the app in a browser at `http://127.0.0.1:8000/`.
