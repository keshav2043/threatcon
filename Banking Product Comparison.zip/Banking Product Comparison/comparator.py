from typing import List, Dict, Any, Optional


def normalize(value: Optional[float], minimum: float, maximum: float) -> float:
    if value is None:
        return 0.0
    if maximum == minimum:
        return 1.0
    return max(0.0, min(1.0, (value - minimum) / (maximum - minimum)))


def score_product(
    item: Dict[str, Any],
    product_type: str,
    prefs: Dict[str, float],
    amount: Optional[float] = None,
    tenure_months: Optional[int] = None,
) -> float:
    ir = item.get("interest_rate")
    fees = item.get("fees")
    benefits = item.get("benefits") or []
    min_balance = item.get("min_balance")
    product = product_type.lower()

    weights = {
        "interest": prefs.get("interest", 1.0),
        "fees": prefs.get("fees", 1.0),
        "benefits": prefs.get("benefits", 0.5),
        "term": prefs.get("term", 0.3),
        "amount": prefs.get("amount", 0.2),
    }

    # Build normalized metrics
    score = 0.0
    if product in ("savings", "fd"):
        score += weights["interest"] * normalize(ir, 0.0, 12.0)
    else:
        score += weights["interest"] * (1.0 - normalize(ir, 0.0, 30.0))

    score += weights["fees"] * (1.0 - normalize(fees, 0.0, 1000.0))
    score += weights["benefits"] * normalize(len(benefits), 0.0, 10.0)

    if tenure_months and item.get("tenure_months"):
        term_distance = abs(item["tenure_months"] - tenure_months)
        score += weights["term"] * max(0.0, 1.0 - term_distance / max(tenure_months, 12))

    if amount and min_balance:
        score += weights["amount"] * (0.0 if amount < min_balance else 1.0)

    if item.get("source") == "profile":
        score *= 0.95
    elif item.get("source") == "scraped+profile":
        score *= 1.02

    return round(score, 4)


def rank_products(
    items: List[Dict[str, Any]],
    product_type: str,
    prefs: Dict[str, float],
    amount: Optional[float] = None,
    tenure_months: Optional[int] = None,
    top_k: int = 3,
) -> List[Dict[str, Any]]:
    scored: List[Dict[str, Any]] = []
    for it in items:
        it_score = score_product(it, product_type, prefs, amount, tenure_months)
        scored.append({**it, "score": it_score})
    ranked = sorted(scored, key=lambda x: x["score"], reverse=True)
    return ranked[:top_k]
