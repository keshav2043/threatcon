const productEl = document.getElementById('product');
const amountEl = document.getElementById('amount');
const tenureEl = document.getElementById('tenure');
const cardsEl = document.getElementById('cards');
const summaryEl = document.getElementById('summary');
const detailsEl = document.getElementById('details');
const applyBtn = document.getElementById('apply');
const sortEl = document.getElementById('sort');

applyBtn.addEventListener('click', fetchAndRender);
sortEl.addEventListener('change', fetchAndRender);

async function fetchAndRender() {
  const product = productEl.value;
  const preferences = {
    interest: parseFloat(document.getElementById('interest').value) || 1,
    fees: parseFloat(document.getElementById('fees').value) || 1,
    benefits: parseFloat(document.getElementById('benefits').value) || 0.5,
  };
  const payload = {
    product_type: product,
    amount: parseFloat(amountEl.value) || 0,
    tenure_months: parseInt(tenureEl.value, 10) || 0,
    preferences,
  };

  summaryEl.textContent = 'Loading recommendations...';
  cardsEl.innerHTML = '';
  detailsEl.innerHTML = '';

  try {
    const resp = await fetch('/compare', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!resp.ok) {
      const txt = await resp.text();
      throw new Error(txt || 'Server error');
    }
    const data = await resp.json();
    renderCards(data.results || []);
    summaryEl.textContent = `Showing ${data.results.length} offers for ${product.replace('_', ' ')}.`;
  } catch (err) {
    summaryEl.innerHTML = `<pre>${escapeHtml(err.message || err)}</pre>`;
  }
}

function renderCards(results) {
  if (!results.length) {
    cardsEl.innerHTML = '<div class="empty">No offers found. Confirm `bank_list.json` and profile data are available.</div>';
    return;
  }

  const sort = sortEl.value;
  if (sort === 'interest_desc') {
    results.sort((a, b) => (b.interest_rate || 0) - (a.interest_rate || 0));
  } else if (sort === 'interest_asc') {
    results.sort((a, b) => (a.interest_rate || 0) - (b.interest_rate || 0));
  } else if (sort === 'fees_asc') {
    results.sort((a, b) => (a.fees || 0) - (b.fees || 0));
  }

  cardsEl.innerHTML = results
    .map((item, index) => cardHtml(item, index))
    .join('');

  document.querySelectorAll('.card').forEach(el => {
    el.addEventListener('click', () => {
      const idx = parseInt(el.dataset.idx, 10);
      showDetails(results[idx]);
    });
  });
}

function cardHtml(item, index) {
  const interest = item.interest_rate != null ? `${item.interest_rate}%` : 'N/A';
  const fees = item.fees != null ? `NPR ${item.fees}` : 'N/A';
  const benefits = (item.benefits || []).slice(0, 4).map(b => `<li>${escapeHtml(b)}</li>`).join('');
  const sourceBadge = item.source ? `Source: ${escapeHtml(item.source)}` : '';
  return `
    <article class="card" data-idx="${index}">
      <div class="card-head">
        <div>
          <h3>${escapeHtml(item.bank)}</h3>
          <div class="source">${sourceBadge}</div>
        </div>
        <div class="score">${(item.score || 0).toFixed(2)}</div>
      </div>
      <div class="card-body">
        <p><strong>Interest:</strong> ${escapeHtml(interest)}</p>
        <p><strong>Fees:</strong> ${escapeHtml(fees)}</p>
        <p><strong>Min balance:</strong> ${item.min_balance != null ? `NPR ${item.min_balance}` : 'N/A'}</p>
        <ul class="benefits">${benefits}</ul>
      </div>
      <div class="card-footer">
        <a class="btn" href="${item.url || '#'}" target="_blank" rel="noopener">Visit product page</a>
      </div>
    </article>
  `;
}

function showDetails(item) {
  detailsEl.innerHTML = `
    <h2>${escapeHtml(item.bank)} details</h2>
    <p><strong>Score:</strong> ${(item.score || 0).toFixed(2)}</p>
    <p><strong>Interest:</strong> ${item.interest_rate != null ? `${item.interest_rate}%` : 'N/A'}</p>
    <p><strong>Fees:</strong> ${item.fees != null ? `NPR ${item.fees}` : 'N/A'}</p>
    <p><strong>Tenure coverage:</strong> ${item.tenure_months != null ? `${item.tenure_months} months` : 'N/A'}</p>
    <p><strong>Source:</strong> ${escapeHtml(item.source || 'profile')}</p>
    <h3>Benefits</h3>
    <ul>${(item.benefits || []).map(b => `<li>${escapeHtml(b)}</li>`).join('')}</ul>
    <p><a class="btn" href="${item.url || '#'}" target="_blank" rel="noopener">Open product page</a></p>
  `;
}

function escapeHtml(s) {
  return String(s || '').replace(/[&<>"']/g, c => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  }[c]));
}

fetchAndRender();
