const navToggle = document.querySelector('.nav-toggle');
const navMenu = document.querySelector('.site-nav');
const contactForm = document.getElementById('contactForm');

if (navToggle && navMenu) {
  navToggle.addEventListener('click', () => {
    navMenu.classList.toggle('active');
  });
}

if (contactForm) {
  contactForm.addEventListener('submit', (event) => {
    event.preventDefault();
    const name = contactForm.querySelector('#name').value.trim();
    const email = contactForm.querySelector('#email').value.trim();
    const message = contactForm.querySelector('#message').value.trim();

    if (!name || !email || !message) {
      alert('Please complete all fields before sending your message.');
      return;
    }

    alert(`Thank you, ${name}! Your message has been received.`);
    contactForm.reset();
  });
}
