const lodgeForm = document.getElementById('lodgeForm');
const branchInput = document.getElementById('branchInput');
const deviceTypeInput = document.getElementById('deviceTypeInput');
const deviceIdInput = document.getElementById('deviceIdInput');
const expiryInput = document.getElementById('expiryInput');
const costInput = document.getElementById('costInput');
const issueInput = document.getElementById('issueInput');
const courierCompanyInput = document.getElementById('courierCompanyInput');
const trackingInput = document.getElementById('trackingInput');
const lodgeMessage = document.getElementById('lodgeMessage');

const statusFilter = document.getElementById('statusFilter');
const branchFilter = document.getElementById('branchFilter');
const caseTableBody = document.querySelector('#caseTable tbody');
const courierTableBody = document.querySelector('#courierTable tbody');
const deviceTableBody = document.querySelector('#deviceTable tbody');
const notificationTableBody = document.querySelector('#notificationTable tbody');
const totalCostElement = document.getElementById('totalCost');
const expiredCountElement = document.getElementById('expiredCount');
const dueSoonCountElement = document.getElementById('dueSoonCount');

const caseEditor = document.getElementById('caseEditor');
const reviewForm = document.getElementById('reviewForm');
const editCaseId = document.getElementById('editCaseId');
const statusInput = document.getElementById('statusInput');
const editCostInput = document.getElementById('editCostInput');
const responseInput = document.getElementById('responseInput');
const courierStatusInput = document.getElementById('courierStatusInput');
const editTrackingInput = document.getElementById('editTrackingInput');
const closeEditor = document.getElementById('closeEditor');
const sendEmailButton = document.getElementById('sendEmailButton');
const reviewMessage = document.getElementById('reviewMessage');

const courierForm = document.getElementById('courierForm');
const courierCaseId = document.getElementById('courierCaseId');
const courierCompanyUpdate = document.getElementById('courierCompanyUpdate');
const courierTrackingUpdate = document.getElementById('courierTrackingUpdate');
const courierStatusUpdate = document.getElementById('courierStatusUpdate');
const courierMessage = document.getElementById('courierMessage');

const roleSelect = document.getElementById('roleSelect');
const roleBranchLabel = document.getElementById('roleBranchLabel');
const roleBranchSelect = document.getElementById('roleBranchSelect');
const exportButton = document.getElementById('exportButton');
const importButton = document.getElementById('importButton');
const resetButton = document.getElementById('resetButton');
const importFileInput = document.getElementById('importFileInput');

const STORAGE_KEY_CASES = 'it-maintenance-cases';
const STORAGE_KEY_NOTIFICATIONS = 'it-maintenance-notifications';

let cases = [];
let notifications = [];

function loadStorage() {
  const rawCases = localStorage.getItem(STORAGE_KEY_CASES);
  const rawNotifications = localStorage.getItem(STORAGE_KEY_NOTIFICATIONS);
  cases = rawCases ? JSON.parse(rawCases) : [];
  notifications = rawNotifications ? JSON.parse(rawNotifications) : [];
}

function saveStorage() {
  localStorage.setItem(STORAGE_KEY_CASES, JSON.stringify(cases));
  localStorage.setItem(STORAGE_KEY_NOTIFICATIONS, JSON.stringify(notifications));
}

function handleEditAction(caseId) {
  if (!caseId) return;
  if (caseEditor) {
    openCaseEditor(caseId);
  } else {
    window.location.href = `review.html?caseId=${encodeURIComponent(caseId)}`;
  }
}

function applyRoleMode() {
  if (!roleSelect) return;
  const role = roleSelect.value;
  const isBranch = role === 'branch';
  if (roleBranchLabel) {
    roleBranchLabel.classList.toggle('hidden', !isBranch);
  }
  if (roleBranchSelect) {
    roleBranchSelect.disabled = !isBranch;
  }
  if (branchFilter) {
    branchFilter.disabled = isBranch;
    if (isBranch && roleBranchSelect) {
      branchFilter.value = roleBranchSelect.value;
    }
  }
  document.body.dataset.userRole = role;
  renderCaseTable();
}

function downloadJSON(data, fileName) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = fileName;
  anchor.click();
  URL.revokeObjectURL(url);
}

function exportData() {
  const payload = {
    exportedAt: new Date().toISOString(),
    cases,
    notifications,
  };
  downloadJSON(payload, 'it-maintenance-backup.json');
}

function importData(file) {
  const reader = new FileReader();
  reader.onload = (event) => {
    try {
      const parsed = JSON.parse(event.target.result);
      if (!parsed || !Array.isArray(parsed.cases) || !Array.isArray(parsed.notifications)) {
        throw new Error('Invalid import file');
      }
      const newCases = parsed.cases.filter((item) => !cases.some((existing) => existing.id === item.id));
      const newNotifications = parsed.notifications.filter((note) => !notifications.some((existing) => existing.id === note.id));
      cases = [...cases, ...newCases];
      notifications = [...notifications, ...newNotifications];
      saveStorage();
      renderAllViews();
      showTemporaryMessage(lodgeMessage, 'Import completed successfully.');
    } catch (error) {
      showTemporaryMessage(lodgeMessage, 'Unable to import data. Use a valid JSON file.', true);
    }
  };
  reader.readAsText(file);
}

function resetData() {
  const confirmed = window.confirm('Reset all tracker data? This will remove stored cases and notifications permanently.');
  if (!confirmed) return;
  cases = [];
  notifications = [];
  saveStorage();
  renderAllViews();
  showTemporaryMessage(lodgeMessage, 'All data has been reset.');
}

function createCase(data) {
  const newCase = {
    id: `CASE-${Date.now()}`,
    branch: data.branch,
    deviceType: data.deviceType,
    deviceId: data.deviceId,
    expiry: data.expiry,
    cost: Number(data.cost),
    issue: data.issue,
    status: 'Open',
    lodgedAt: new Date().toISOString(),
    response: '',
    courierCompany: data.courierCompany || '',
    trackingNumber: data.trackingNumber || '',
    courierStatus: data.trackingNumber ? 'Picked up' : 'Not shipped',
  };
  cases.unshift(newCase);
  saveStorage();
  renderAllViews();
  return newCase;
}

function renderAllViews() {
  renderCaseTable();
  renderCourierTable();
  renderDeviceTable();
  renderNotificationTable();
  renderSummaryStats();
}

function renderCaseTable() {
  if (!caseTableBody) return;

  caseTableBody.innerHTML = '';

  // If neither filter control exists, show recent cases (useful for lodge.html)
  const noFilters = !statusFilter && !branchFilter;
  let toShow = [];

  if (noFilters) {
    toShow = cases.slice(0, 50); // recent first (cases are unshifted)
  } else {
    const statusValue = statusFilter ? statusFilter.value : 'all';
    const branchValue = branchFilter ? branchFilter.value : 'all';
    toShow = cases.filter((item) => {
      if (statusValue !== 'all' && item.status !== statusValue) return false;
      if (branchValue !== 'all' && item.branch !== branchValue) return false;
      return true;
    });
  }

  if (!toShow.length) {
    caseTableBody.innerHTML = '<tr><td colspan="8" class="empty">No cases available.</td></tr>';
    return;
  }

  toShow.forEach((item) => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${item.id}</td>
      <td>${item.branch}</td>
      <td>${item.deviceType} / ${item.deviceId}</td>
      <td>${item.issue}</td>
      <td>${getStatusTag(item.status)}</td>
      <td>$${item.cost.toFixed(2)}</td>
      <td>${formatDate(item.expiry)}</td>
      <td>
        <button class="btn btn-secondary" data-action="edit" data-id="${item.id}">Edit</button>
      </td>
    `;
    caseTableBody.appendChild(row);
  });
}

function renderCourierTable() {
  if (!courierTableBody) return;
  courierTableBody.innerHTML = '';
  if (!cases.length) {
    courierTableBody.innerHTML = '<tr><td colspan="4" class="empty">No courier records available.</td></tr>';
    return;
  }

  cases.forEach((item) => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${item.id}</td>
      <td>${item.courierCompany || '—'}</td>
      <td>${item.trackingNumber || '—'}</td>
      <td>${item.courierStatus}</td>
      <td><button class="btn btn-secondary" data-action="edit" data-id="${item.id}">Edit</button></td>
    `;
    courierTableBody.appendChild(row);
  });
}

function renderDeviceTable() {
  if (!deviceTableBody) return;
  deviceTableBody.innerHTML = '';
  if (!cases.length) {
    deviceTableBody.innerHTML = '<tr><td colspan="6" class="empty">No device records available.</td></tr>';
    return;
  }

  cases.forEach((item) => {
    const row = document.createElement('tr');
    const expired = isExpired(item.expiry);
    row.innerHTML = `
      <td>${item.deviceId}</td>
      <td>${item.branch}</td>
      <td>${item.deviceType}</td>
      <td>${formatDate(item.expiry)} ${expired ? '<span class="tag tag-expired">Expired</span>' : ''}</td>
      <td>$${item.cost.toFixed(2)}</td>
      <td>${item.id}</td>
      <td><button class="btn btn-secondary" data-action="edit" data-id="${item.id}">Edit</button></td>
    `;
    deviceTableBody.appendChild(row);
  });
}

function renderNotificationTable() {
  if (!notificationTableBody) return;
  notificationTableBody.innerHTML = '';
  if (!notifications.length) {
    notificationTableBody.innerHTML = '<tr><td colspan="5" class="empty">No notifications have been sent yet.</td></tr>';
    return;
  }

  notifications.forEach((note) => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${formatDateTime(note.sentAt)}</td>
      <td>${note.branch}</td>
      <td>${note.caseId}</td>
      <td>${note.subject}</td>
      <td>${note.message}</td>
      <td><button class="btn btn-secondary" data-action="edit" data-id="${note.caseId}">View case</button></td>
    `;
    notificationTableBody.appendChild(row);
  });
}

function renderSummaryStats() {
  const totalCost = cases.reduce((sum, item) => sum + item.cost, 0);
  const expiredCount = cases.filter((item) => isExpired(item.expiry)).length;
  const dueSoonCount = cases.filter((item) => isDueSoon(item.expiry)).length;
  if (totalCostElement) {
    totalCostElement.textContent = `$${totalCost.toFixed(2)}`;
  }
  if (expiredCountElement) {
    expiredCountElement.textContent = expiredCount;
  }
  if (dueSoonCountElement) {
    dueSoonCountElement.textContent = dueSoonCount;
  }
}

function getStatusTag(status) {
  const normalized = status.toLowerCase();
  let className = 'tag-open';
  if (normalized.includes('progress')) className = 'tag-progress';
  if (normalized.includes('awaiting')) className = 'tag-awaiting';
  if (normalized.includes('completed')) className = 'tag-completed';
  return `<span class="tag ${className}">${status}</span>`;
}

function formatDate(dateString) {
  const date = new Date(dateString);
  if (Number.isNaN(date.getTime())) return '—';
  return date.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
}

function formatDateTime(dateString) {
  const date = new Date(dateString);
  if (Number.isNaN(date.getTime())) return '—';
  return date.toLocaleString(undefined, { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

function isExpired(dateString) {
  return new Date(dateString) < new Date();
}

function isDueSoon(dateString) {
  const today = new Date();
  const target = new Date(dateString);
  const diffDays = Math.ceil((target - today) / (1000 * 60 * 60 * 24));
  return diffDays >= 0 && diffDays <= 30;
}

function openCaseEditor(caseId) {
  const selectedCase = cases.find((item) => item.id === caseId);
  if (!selectedCase) return;
  editCaseId.value = selectedCase.id;
  statusInput.value = selectedCase.status;
  editCostInput.value = selectedCase.cost.toFixed(2);
  responseInput.value = selectedCase.response;
  courierStatusInput.value = selectedCase.courierStatus;
  editTrackingInput.value = selectedCase.trackingNumber;
  reviewMessage.textContent = '';
  caseEditor.classList.remove('hidden');
  caseEditor.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function closeCaseEditor() {
  caseEditor.classList.add('hidden');
}

function sendNotification(caseItem, customMessage) {
  const subject = `Maintenance update for ${caseItem.deviceId}`;
  const message = customMessage || `The status of your maintenance case ${caseItem.id} has been updated to ${caseItem.status}. Response: ${caseItem.response || 'No additional notes.'}`;
  const notification = {
    id: `NOTIF-${Date.now()}`,
    caseId: caseItem.id,
    branch: caseItem.branch,
    subject,
    message,
    sentAt: new Date().toISOString(),
  };
  notifications.unshift(notification);
  saveStorage();
  renderNotificationTable();
  showTemporaryMessage(reviewMessage, 'Notification sent to branch.');
}

function getActiveCaseById(caseId) {
  return cases.find((item) => item.id === caseId);
}

function updateCase(caseId, updates) {
  const item = getActiveCaseById(caseId);
  if (!item) return;
  Object.assign(item, updates);
  saveStorage();
  renderAllViews();
}

function showTemporaryMessage(element, message, isError = false) {
  if (element) {
    element.textContent = message;
    element.style.color = isError ? 'var(--danger)' : 'var(--success)';
  } else {
    console.log(message);
  }
  setTimeout(() => {
    if (element) {
      element.textContent = '';
      element.style.color = '';
    }
  }, 4000);
}

if (lodgeForm) {
  lodgeForm.addEventListener('submit', (event) => {
  event.preventDefault();
  const branch = branchInput.value;
  const deviceType = deviceTypeInput.value;
  const deviceId = deviceIdInput.value.trim();
  const expiry = expiryInput.value;
  const cost = costInput.value;
  const issue = issueInput.value.trim();
  const courierCompany = courierCompanyInput.value.trim();
  const trackingNumber = trackingInput.value.trim();

  if (!branch || !deviceType || !deviceId || !expiry || !issue) {
    showTemporaryMessage(lodgeMessage, 'Complete all required fields.', true);
    return;
  }

  createCase({ branch, deviceType, deviceId, expiry, cost, issue, courierCompany, trackingNumber });
  lodgeForm.reset();
  showTemporaryMessage(lodgeMessage, 'Maintenance case lodged successfully.');
  });
}

if (statusFilter) {
  statusFilter.addEventListener('change', renderCaseTable);
}
if (branchFilter) {
  branchFilter.addEventListener('change', renderCaseTable);
}

document.addEventListener('click', (event) => {
  const actionButton = event.target.closest('[data-action="edit"]');
  if (!actionButton) return;
  handleEditAction(actionButton.dataset.id);
});

if (reviewForm) {
  reviewForm.addEventListener('submit', (event) => {
  event.preventDefault();
  const caseId = editCaseId.value;
  const updatedStatus = statusInput.value;
  const updatedCost = Number(editCostInput.value);
  const response = responseInput.value.trim();
  const courierStatus = courierStatusInput.value;
  const trackingNumber = editTrackingInput.value.trim();

  if (!caseId || Number.isNaN(updatedCost)) {
    reviewMessage.textContent = 'Please provide valid case details.';
    reviewMessage.style.color = 'var(--danger)';
    return;
  }

  updateCase(caseId, {
    status: updatedStatus,
    cost: updatedCost,
    response,
    courierStatus,
    trackingNumber,
  });
  reviewMessage.textContent = 'Case updated successfully.';
  reviewMessage.style.color = 'var(--success)';
  });
}

if (closeEditor) {
  closeEditor.addEventListener('click', () => {
    closeCaseEditor();
  });
}

if (sendEmailButton) {
  sendEmailButton.addEventListener('click', () => {
    const caseId = editCaseId.value;
    const selectedCase = getActiveCaseById(caseId);
    if (!selectedCase) return;
    updateCase(caseId, {
      status: statusInput.value,
      cost: Number(editCostInput.value),
      response: responseInput.value.trim(),
      courierStatus: courierStatusInput.value,
      trackingNumber: editTrackingInput.value.trim(),
    });
    sendNotification(selectedCase);
  });
}

if (courierForm) {
  courierForm.addEventListener('submit', (event) => {
    event.preventDefault();
    const caseId = courierCaseId.value.trim();
    const courierCompany = courierCompanyUpdate.value.trim();
    const trackingNumber = courierTrackingUpdate.value.trim();
    const status = courierStatusUpdate.value;

    const item = getActiveCaseById(caseId);
    if (!item) {
      showTemporaryMessage(courierMessage, 'Case ID not found.', true);
      return;
    }

    updateCase(caseId, {
      courierCompany,
      trackingNumber,
      courierStatus: status,
    });
    courierForm.reset();
    showTemporaryMessage(courierMessage, 'Courier info updated.');
  });
}

if (roleSelect) {
  roleSelect.addEventListener('change', applyRoleMode);
}
if (roleBranchSelect) {
  roleBranchSelect.addEventListener('change', () => {
    if (roleSelect && roleSelect.value === 'branch' && branchFilter) {
      branchFilter.value = roleBranchSelect.value;
      renderCaseTable();
    }
  });
}
if (exportButton) {
  exportButton.addEventListener('click', exportData);
}
if (importButton) {
  importButton.addEventListener('click', () => importFileInput.click());
}
if (importFileInput) {
  importFileInput.addEventListener('change', (event) => {
    const file = event.target.files[0];
    if (file) {
      const proceed = window.confirm('Import JSON data into the tracker? Existing data will be merged and duplicates skipped.');
      if (proceed) {
        importData(file);
      }
    }
    importFileInput.value = '';
  });
}
if (resetButton) {
  resetButton.addEventListener('click', resetData);
}

window.addEventListener('DOMContentLoaded', () => {
  loadStorage();
  applyRoleMode();
  renderAllViews();
  const queryCaseId = new URLSearchParams(window.location.search).get('caseId');
  if (queryCaseId && caseEditor) {
    openCaseEditor(queryCaseId);
  }
});
