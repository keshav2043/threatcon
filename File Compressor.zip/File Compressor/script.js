const compressFileInput = document.getElementById('compressFileInput');
const compressRange = document.getElementById('compressRange');
const compressRatio = document.getElementById('compressRatio');
const outputFormat = document.getElementById('outputFormat');
const compressButton = document.getElementById('compressButton');
const compressResult = document.getElementById('compressResult');

const splitFileInput = document.getElementById('splitFileInput');
const splitMethod = document.getElementById('splitMethod');
const splitValueLabel = document.getElementById('splitValueLabel');
const splitValue = document.getElementById('splitValue');
const splitButton = document.getElementById('splitButton');
const splitResult = document.getElementById('splitResult');

const mergeFileInput = document.getElementById('mergeFileInput');
const mergeMode = document.getElementById('mergeMode');
const mergeButton = document.getElementById('mergeButton');
const mergeResult = document.getElementById('mergeResult');
const pdfLibUrls = [
  'https://cdn.jsdelivr.net/npm/pdf-lib@1.18.0/dist/pdf-lib.min.js',
  'https://unpkg.com/pdf-lib@1.18.0/dist/pdf-lib.min.js'
];

async function getPdfLib() {
  if (window.PDFLib) {
    return window.PDFLib;
  }

  for (const url of pdfLibUrls) {
    const existing = document.querySelector(`script[src="${url}"]`);
    if (existing && window.PDFLib) {
      return window.PDFLib;
    }

    try {
      await loadScript(url);
      if (window.PDFLib) {
        return window.PDFLib;
      }
    } catch (error) {
      // Try next CDN if the current one fails.
    }
  }

  throw new Error('Failed to load PDFLib from CDN. Check your internet connection or try again later.');
}

function loadScript(src) {
  return new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = src;
    script.defer = true;
    script.onload = resolve;
    script.onerror = () => reject(new Error(`Failed to load script: ${src}`));
    document.head.appendChild(script);
  });
}

compressRange.addEventListener('input', () => {
  compressRatio.textContent = `${compressRange.value}%`;
});

const splitLabelText = document.getElementById('splitLabelText');

splitMethod.addEventListener('change', () => {
  if (splitMethod.value === 'size') {
    splitLabelText.textContent = 'Size per part (MB)';
    splitValue.min = '1';
    splitValue.value = '1';
  } else {
    splitLabelText.textContent = 'Number of parts';
    splitValue.min = '2';
    splitValue.value = '2';
  }
});

compressButton.addEventListener('click', async () => {
  compressResult.innerHTML = '';
  const file = compressFileInput.files?.[0];
  if (!file) {
    compressResult.textContent = 'Please choose a PDF or image file first.';
    return;
  }

  try {
    const quality = Number(compressRange.value) / 100;
    let result;

    if (file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf')) {
      result = await compressPdf(file);
    } else if (file.type.startsWith('image/') || /\.(jpe?g|png|webp|gif|bmp)$/i.test(file.name)) {
      const format = outputFormat.value === 'auto' ? file.type : outputFormat.value;
      result = await compressImage(file, format, quality);
    } else {
      compressResult.textContent = 'Unsupported file type. Please use a PDF or an image file.';
      return;
    }

    const compressedBlob = result.blob;
    const outputName = result.name;
    const beforeSize = formatBytes(file.size);
    const afterSize = formatBytes(compressedBlob.size);
    const ratio = ((1 - compressedBlob.size / file.size) * 100).toFixed(1);

    const link = createDownloadLink(compressedBlob, outputName, 'Download compressed file');
    compressResult.innerHTML = `
      <p><strong>Original:</strong> ${beforeSize}</p>
      <p><strong>Compressed:</strong> ${afterSize} (${ratio}% smaller)</p>
    `;
    compressResult.appendChild(link);

    if (compressedBlob.type.startsWith('image/')) {
      const img = document.createElement('img');
      img.className = 'preview-image';
      img.src = URL.createObjectURL(compressedBlob);
      img.alt = 'Compressed preview';
      compressResult.appendChild(img);
    }

    if (compressedBlob.type === 'application/pdf') {
      const iframe = document.createElement('iframe');
      iframe.className = 'preview-pdf';
      iframe.src = URL.createObjectURL(compressedBlob);
      compressResult.appendChild(iframe);
    }
  } catch (error) {
    compressResult.textContent = `Compression failed: ${error.message}`;
  }
});

splitButton.addEventListener('click', async () => {
  splitResult.innerHTML = '';
  const file = splitFileInput.files?.[0];
  const valueInput = document.getElementById('splitValue');
  if (!file || !valueInput) {
    splitResult.textContent = 'Please choose a file and enter a valid split value.';
    return;
  }

  const splitValueNumber = Number(valueInput.value);
  if (splitValueNumber < 1) {
    splitResult.textContent = 'Enter a valid split size or part count.';
    return;
  }

  try {
    const buffer = await file.arrayBuffer();
    const fileSize = buffer.byteLength;
    let parts = [];

    if (splitMethod.value === 'parts') {
      const count = Math.max(2, Math.round(splitValueNumber));
      const partSize = Math.ceil(fileSize / count);
      for (let i = 0; i < count; i++) {
        const start = i * partSize;
        const end = Math.min(start + partSize, fileSize);
        if (start >= end) break;
        parts.push(buffer.slice(start, end));
      }
    } else {
      const sizeMB = Math.max(1, splitValueNumber);
      const partSize = sizeMB * 1024 * 1024;
      for (let offset = 0; offset < fileSize; offset += partSize) {
        parts.push(buffer.slice(offset, Math.min(offset + partSize, fileSize)));
      }
    }

    if (!parts.length) {
      splitResult.textContent = 'No parts generated. Adjust the split settings and try again.';
      return;
    }

    const list = document.createElement('div');
    list.className = 'part-list';
    parts.forEach((partBuffer, index) => {
      const blob = new Blob([partBuffer], { type: 'application/octet-stream' });
      const name = `${file.name}.part${index + 1}`;
      const item = document.createElement('div');
      item.className = 'part-item';
      item.innerHTML = `<strong>Part ${index + 1}:</strong> ${formatBytes(blob.size)}`;
      item.appendChild(createDownloadLink(blob, name, 'Download part'));
      list.appendChild(item);
    });

    splitResult.appendChild(list);
  } catch (error) {
    splitResult.textContent = `Split failed: ${error.message}`;
  }
});

mergeButton.addEventListener('click', async () => {
  mergeResult.innerHTML = '';
  const files = Array.from(mergeFileInput.files || []);
  if (files.length < 2) {
    mergeResult.textContent = 'Choose at least two files to merge.';
    return;
  }

  try {
    let mergedBlob;
    let outputName;

    if (mergeMode.value === 'pdf') {
      const allPdf = files.every((file) => file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf'));
      if (!allPdf) {
        mergeResult.textContent = 'PDF merge requires only PDF files.';
        return;
      }
      const mergedBytes = await mergePdfFiles(files);
      mergedBlob = new Blob([mergedBytes], { type: 'application/pdf' });
      outputName = 'merged.pdf';
    } else {
      const buffers = await Promise.all(files.map((file) => file.arrayBuffer()));
      const totalLength = buffers.reduce((sum, buf) => sum + buf.byteLength, 0);
      const merged = new Uint8Array(totalLength);
      let offset = 0;
      buffers.forEach((buf) => {
        merged.set(new Uint8Array(buf), offset);
        offset += buf.byteLength;
      });
      mergedBlob = new Blob([merged], { type: 'application/octet-stream' });
      outputName = `merged_${files[0].name}`;
    }

    const link = createDownloadLink(mergedBlob, outputName, 'Download merged file');
    mergeResult.appendChild(link);
  } catch (error) {
    mergeResult.textContent = `Merge failed: ${error.message}`;
  }
});

async function compressPdf(file) {
  const pdfLib = await getPdfLib();
  const bytes = await file.arrayBuffer();
  const pdfDoc = await pdfLib.PDFDocument.load(bytes, { ignoreEncryption: true });
  const compressedBytes = await pdfDoc.save({ useObjectStreams: true, compress: true });
  return { blob: new Blob([compressedBytes], { type: 'application/pdf' }), name: `${file.name.replace(/\.pdf$/i, '')}-compressed.pdf` };
}

async function compressImage(file, outputType, quality) {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = async () => {
      const canvas = document.createElement('canvas');
      canvas.width = image.naturalWidth;
      canvas.height = image.naturalHeight;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(image, 0, 0);
      const targetType = outputType === 'auto' ? file.type : outputType;

      canvas.toBlob((blob) => {
        if (!blob) {
          reject(new Error('Unable to generate compressed image.'));
          return;
        }
        const extension = getExtensionForMime(targetType, file.name);
        resolve({ blob, name: `${file.name.replace(/\.[^/.]+$/, '')}-compressed.${extension}` });
      }, targetType, quality);
    };
    image.onerror = () => reject(new Error('Unable to load the image file.'));
    image.src = URL.createObjectURL(file);
  });
}

function getExtensionForMime(mimeType, originalName) {
  if (mimeType === 'image/jpeg') return 'jpg';
  if (mimeType === 'image/png') return 'png';
  if (mimeType === 'image/webp') return 'webp';
  if (mimeType === 'application/pdf') return 'pdf';
  const match = originalName.match(/\.([^/.]+)$/);
  return match ? match[1] : 'bin';
}

function createDownloadLink(blob, filename, label) {
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  link.textContent = label;
  link.className = 'download-link';
  return link;
}

function formatBytes(bytes) {
  if (bytes === 0) return '0 B';
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${(bytes / 1024 ** i).toFixed(2)} ${sizes[i]}`;
}

async function mergePdfFiles(files) {
  const pdfLib = await getPdfLib();
  const mergedPdf = await pdfLib.PDFDocument.create();
  for (const file of files) {
    const bytes = await file.arrayBuffer();
    const pdf = await pdfLib.PDFDocument.load(bytes, { ignoreEncryption: true });
    const copiedPages = await mergedPdf.copyPages(pdf, pdf.getPageIndices());
    copiedPages.forEach((page) => mergedPdf.addPage(page));
  }
  return await mergedPdf.save({ useObjectStreams: true, compress: true });
}
